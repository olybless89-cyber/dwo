/**
 * Seed script: admin user + Tesla car catalog + sample giveaway
 * Run: pnpm --filter @workspace/api-server run seed
 */
import bcrypt from "bcryptjs";
import { db, usersTable, carsTable, giveawaysTable } from "@workspace/db";
import { eq } from "drizzle-orm";

async function seed() {
  console.log("🌱 Starting seed...");

  // ── Admin User ──────────────────────────────────────────────────────────────
  const adminEmail = "admin@teslapro.com";
  const existingAdmin = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(eq(usersTable.email, adminEmail))
    .limit(1);

  if (existingAdmin.length === 0) {
    const passwordHash = await bcrypt.hash("Admin@Tesla2026", 12);
    await db.insert(usersTable).values({
      email: adminEmail,
      passwordHash,
      firstName: "Tesla",
      lastName: "Admin",
      role: "admin",
      status: "active",
      balance: "0",
    });
    console.log("✅ Admin user created: admin@teslapro.com / Admin@Tesla2026");
  } else {
    console.log("ℹ️  Admin user already exists");
  }

  // ── Tesla Car Catalog ───────────────────────────────────────────────────────
  const existingCars = await db.select({ id: carsTable.id }).from(carsTable).limit(1);
  if (existingCars.length === 0) {
    const cars = [
      {
        name: "Model S Plaid",
        model: "Model S",
        year: 2024,
        price: "89990",
        category: "Sedan",
        description: "The quickest production car ever made. Tri-motor all-wheel drive with 1,020 horsepower.",
        imageUrl: "https://images.unsplash.com/photo-1617788138017-80ad40651399?w=800&q=80",
        range: "396 mi",
        topSpeed: "200 mph",
        acceleration: "1.99s 0-60",
        available: true,
      },
      {
        name: "Model S Long Range",
        model: "Model S",
        year: 2024,
        price: "74990",
        category: "Sedan",
        description: "Dual motor all-wheel drive with exceptional efficiency and award-winning interior.",
        imageUrl: "https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=800&q=80",
        range: "405 mi",
        topSpeed: "155 mph",
        acceleration: "3.1s 0-60",
        available: true,
      },
      {
        name: "Model 3 Performance",
        model: "Model 3",
        year: 2024,
        price: "50990",
        category: "Sedan",
        description: "The track-ready version of the world's most popular electric vehicle.",
        imageUrl: "https://images.unsplash.com/photo-1562911791-c7a97b729ec5?w=800&q=80",
        range: "315 mi",
        topSpeed: "162 mph",
        acceleration: "3.1s 0-60",
        available: true,
      },
      {
        name: "Model 3 Long Range",
        model: "Model 3",
        year: 2024,
        price: "45990",
        category: "Sedan",
        description: "The most affordable long-range electric sedan with premium features.",
        imageUrl: "https://images.unsplash.com/photo-1531580710034-91caaef05c02?w=800&q=80",
        range: "341 mi",
        topSpeed: "145 mph",
        acceleration: "4.2s 0-60",
        available: true,
      },
      {
        name: "Model X Plaid",
        model: "Model X",
        year: 2024,
        price: "109990",
        category: "SUV",
        description: "The safest, most capable SUV ever built. Falcon Wing doors and seating for seven.",
        imageUrl: "https://images.unsplash.com/photo-1640961803035-fa5ddf40bafe?w=800&q=80",
        range: "333 mi",
        topSpeed: "163 mph",
        acceleration: "2.5s 0-60",
        available: true,
      },
      {
        name: "Model X Long Range",
        model: "Model X",
        year: 2024,
        price: "94990",
        category: "SUV",
        description: "Premium family SUV with unmatched safety ratings and Falcon Wing rear doors.",
        imageUrl: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?w=800&q=80",
        range: "348 mi",
        topSpeed: "155 mph",
        acceleration: "3.8s 0-60",
        available: true,
      },
      {
        name: "Model Y Performance",
        model: "Model Y",
        year: 2024,
        price: "52990",
        category: "SUV",
        description: "The most versatile electric SUV with dual motor performance and class-leading safety.",
        imageUrl: "https://images.unsplash.com/photo-1619767886558-efdc259cde1a?w=800&q=80",
        range: "303 mi",
        topSpeed: "155 mph",
        acceleration: "3.5s 0-60",
        available: true,
      },
      {
        name: "Model Y Long Range",
        model: "Model Y",
        year: 2024,
        price: "47990",
        category: "SUV",
        description: "The best-selling electric vehicle in the world — now with enhanced range.",
        imageUrl: "https://images.unsplash.com/photo-1661327849979-a9c57dd44f1a?w=800&q=80",
        range: "330 mi",
        topSpeed: "135 mph",
        acceleration: "4.8s 0-60",
        available: true,
      },
      {
        name: "Cybertruck Dual Motor",
        model: "Cybertruck",
        year: 2024,
        price: "79990",
        category: "Truck",
        description: "Built for utility and performance. Exoskeleton stainless steel body with 11,000 lb towing.",
        imageUrl: "https://images.unsplash.com/photo-1663518847013-1b5b9e39c5e2?w=800&q=80",
        range: "340 mi",
        topSpeed: "112 mph",
        acceleration: "4.1s 0-60",
        available: true,
      },
      {
        name: "Cybertruck Foundation Series",
        model: "Cybertruck",
        year: 2024,
        price: "99990",
        category: "Truck",
        description: "The tri-motor Cybertruck with all-wheel drive and maximum towing capability.",
        imageUrl: "https://images.unsplash.com/photo-1662036348985-f4e4afee76c8?w=800&q=80",
        range: "320 mi",
        topSpeed: "130 mph",
        acceleration: "2.6s 0-60",
        available: true,
      },
      {
        name: "Roadster",
        model: "Roadster",
        year: 2025,
        price: "200000",
        category: "Sports",
        description: "The quickest car in the world, with record-setting acceleration and top speed.",
        imageUrl: "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80",
        range: "620 mi",
        topSpeed: "250+ mph",
        acceleration: "1.9s 0-60",
        available: false,
      },
      {
        name: "Semi",
        model: "Semi",
        year: 2024,
        price: "150000",
        category: "Commercial",
        description: "Electric semi-truck with 500 mile range fully loaded and integrated autopilot.",
        imageUrl: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80",
        range: "500 mi",
        topSpeed: "70 mph",
        acceleration: "5.0s 0-60",
        available: true,
      },
    ];

    await db.insert(carsTable).values(cars);
    console.log(`✅ Inserted ${cars.length} Tesla models`);
  } else {
    console.log("ℹ️  Cars already seeded");
  }

  // ── Sample Giveaways ────────────────────────────────────────────────────────
  const existingGiveaways = await db.select({ id: giveawaysTable.id }).from(giveawaysTable).limit(1);
  if (existingGiveaways.length === 0) {
    const endDate1 = new Date();
    endDate1.setDate(endDate1.getDate() + 30);
    const endDate2 = new Date();
    endDate2.setDate(endDate2.getDate() + 60);

    await db.insert(giveawaysTable).values([
      {
        title: "Tesla Model S Plaid Giveaway",
        value: "89990",
        description: "Enter for a chance to win a brand new Tesla Model S Plaid — the quickest production car ever built. One lucky Tesla Pro member will drive away in style.",
        imageUrl: "https://images.unsplash.com/photo-1617788138017-80ad40651399?w=800&q=80",
        endDate: endDate1,
        maxEntries: 1000,
        status: "active",
      },
      {
        title: "Cybertruck Dream Giveaway",
        value: "79990",
        description: "Win the most anticipated vehicle of the decade. The Tesla Cybertruck — yours for free as a Tesla Pro member.",
        imageUrl: "https://images.unsplash.com/photo-1663518847013-1b5b9e39c5e2?w=800&q=80",
        endDate: endDate2,
        maxEntries: 500,
        status: "active",
      },
    ]);
    console.log("✅ Sample giveaways created");
  } else {
    console.log("ℹ️  Giveaways already seeded");
  }

  console.log("🎉 Seed complete!");
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
