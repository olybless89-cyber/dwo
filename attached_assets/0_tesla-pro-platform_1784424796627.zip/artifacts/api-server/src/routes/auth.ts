import { Router } from "express";
import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

function sanitizeUser(user: typeof usersTable.$inferSelect) {
  const { passwordHash: _, ...safe } = user;
  return {
    ...safe,
    balance: parseFloat(safe.balance as unknown as string),
  };
}

// POST /api/auth/register
router.post("/auth/register", async (req, res) => {
  try {
    const { email, password, firstName, lastName } = req.body as {
      email: string;
      password: string;
      firstName: string;
      lastName: string;
    };

    if (!email || !password || !firstName || !lastName) {
      return void res.status(400).json({ error: "All fields are required" });
    }

    const existing = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(eq(usersTable.email, email.toLowerCase()))
      .limit(1);

    if (existing.length > 0) {
      return void res.status(400).json({ error: "Email already registered" });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const referralCode =
      "TP-" + Math.random().toString(36).substr(2, 6).toUpperCase();

    const [user] = await db
      .insert(usersTable)
      .values({
        email: email.toLowerCase(),
        passwordHash,
        firstName,
        lastName,
        referralCode,
      })
      .returning();

    req.session.userId = user.id;
    return void res.status(201).json({ user: sanitizeUser(user) });
  } catch (err) {
    req.log.error(err);
    return void res.status(500).json({ error: "Registration failed" });
  }
});

// POST /api/auth/login
router.post("/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body as { email: string; password: string };

    if (!email || !password) {
      return void res.status(400).json({ error: "Email and password required" });
    }

    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.email, email.toLowerCase()))
      .limit(1);

    if (!user) {
      return void res.status(401).json({ error: "Invalid email or password" });
    }

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      return void res.status(401).json({ error: "Invalid email or password" });
    }

    if (user.status === "suspended") {
      return void res.status(403).json({ error: "Account suspended. Contact support." });
    }

    req.session.userId = user.id;
    return void res.json({ user: sanitizeUser(user) });
  } catch (err) {
    req.log.error(err);
    return void res.status(500).json({ error: "Login failed" });
  }
});

// POST /api/auth/logout
router.post("/auth/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return void res.status(500).json({ error: "Logout failed" });
    }
    res.clearCookie("connect.sid");
    return void res.json({ message: "Logged out successfully" });
  });
});

// GET /api/auth/me
router.get("/auth/me", async (req, res) => {
  if (!req.session.userId) {
    return void res.status(401).json({ error: "Not authenticated" });
  }

  try {
    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, req.session.userId))
      .limit(1);

    if (!user) {
      req.session.destroy(() => {});
      return void res.status(401).json({ error: "User not found" });
    }

    return void res.json(sanitizeUser(user));
  } catch (err) {
    req.log.error(err);
    return void res.status(500).json({ error: "Server error" });
  }
});

export default router;
