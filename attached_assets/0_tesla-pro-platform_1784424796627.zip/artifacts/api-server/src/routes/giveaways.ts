import { Router } from "express";
import { db, giveawaysTable, giveawayEntriesTable, usersTable } from "@workspace/db";
import { eq, desc, count, and, sql } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../middlewares/auth";

const router = Router();

function formatGiveaway(g: typeof giveawaysTable.$inferSelect, userEntries = 0) {
  return {
    ...g,
    value: parseFloat(g.value as unknown as string),
    endDate: g.endDate.toISOString(),
    userEntries,
  };
}

// GET /api/giveaways — public
router.get("/giveaways", async (req, res) => {
  try {
    const userId = req.session?.userId;
    const giveaways = await db
      .select()
      .from(giveawaysTable)
      .orderBy(desc(giveawaysTable.createdAt));

    const result = await Promise.all(
      giveaways.map(async (g) => {
        let userEntries = 0;
        if (userId) {
          const [entry] = await db
            .select({ cnt: count() })
            .from(giveawayEntriesTable)
            .where(
              and(
                eq(giveawayEntriesTable.giveawayId, g.id),
                eq(giveawayEntriesTable.userId, userId),
              ),
            );
          userEntries = entry?.cnt ?? 0;
        }
        return formatGiveaway(g, userEntries);
      }),
    );

    return void res.json(result);
  } catch (err) {
    req.log.error(err);
    return void res.status(500).json({ error: "Server error" });
  }
});

// GET /api/giveaways/:id — public
router.get("/giveaways/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [g] = await db.select().from(giveawaysTable).where(eq(giveawaysTable.id, id)).limit(1);
    if (!g) return void res.status(404).json({ error: "Giveaway not found" });

    let userEntries = 0;
    if (req.session?.userId) {
      const [entry] = await db
        .select({ cnt: count() })
        .from(giveawayEntriesTable)
        .where(
          and(
            eq(giveawayEntriesTable.giveawayId, id),
            eq(giveawayEntriesTable.userId, req.session.userId),
          ),
        );
      userEntries = entry?.cnt ?? 0;
    }

    return void res.json(formatGiveaway(g, userEntries));
  } catch (err) {
    return void res.status(404).json({ error: "Giveaway not found" });
  }
});

// POST /api/giveaways — admin only
router.post("/giveaways", requireAdmin, async (req, res) => {
  try {
    const { title, value, description, imageUrl, endDate, maxEntries } = req.body as {
      title: string;
      value: number;
      description?: string;
      imageUrl: string;
      endDate: string;
      maxEntries: number;
    };

    const [g] = await db
      .insert(giveawaysTable)
      .values({
        title,
        value: value.toString(),
        description,
        imageUrl,
        endDate: new Date(endDate),
        maxEntries,
      })
      .returning();

    return void res.status(201).json(formatGiveaway(g));
  } catch (err) {
    req.log.error(err);
    return void res.status(400).json({ error: "Failed to create giveaway" });
  }
});

// POST /api/giveaways/:id/enter — auth required
router.post("/giveaways/:id/enter", requireAuth, async (req, res) => {
  try {
    const giveawayId = parseInt(req.params.id);
    const userId = req.session.userId!;

    const [g] = await db
      .select()
      .from(giveawaysTable)
      .where(eq(giveawaysTable.id, giveawayId))
      .limit(1);

    if (!g) return void res.status(404).json({ error: "Giveaway not found" });
    if (g.status !== "active") return void res.status(400).json({ error: "Giveaway is not active" });
    if (g.totalEntries >= g.maxEntries) return void res.status(400).json({ error: "Giveaway is full" });

    // Check if already entered
    const [existing] = await db
      .select()
      .from(giveawayEntriesTable)
      .where(
        and(
          eq(giveawayEntriesTable.giveawayId, giveawayId),
          eq(giveawayEntriesTable.userId, userId),
        ),
      )
      .limit(1);

    if (existing) return void res.status(400).json({ error: "Already entered this giveaway" });

    await db.insert(giveawayEntriesTable).values({ giveawayId, userId });

    // Increment entry count
    await db
      .update(giveawaysTable)
      .set({ totalEntries: sql`${giveawaysTable.totalEntries} + 1` })
      .where(eq(giveawaysTable.id, giveawayId));

    return void res.json({ message: "Successfully entered giveaway" });
  } catch (err) {
    req.log.error(err);
    return void res.status(400).json({ error: "Failed to enter giveaway" });
  }
});

export default router;
