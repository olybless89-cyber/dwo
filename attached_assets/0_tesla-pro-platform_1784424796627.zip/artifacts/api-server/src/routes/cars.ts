import { Router } from "express";
import { db, carsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAdmin } from "../middlewares/auth";

const router = Router();

function formatCar(car: typeof carsTable.$inferSelect) {
  return { ...car, price: parseFloat(car.price as unknown as string) };
}

// GET /api/cars — public
router.get("/cars", async (req, res) => {
  try {
    const cars = await db.select().from(carsTable).orderBy(carsTable.createdAt);
    return void res.json(cars.map(formatCar));
  } catch (err) {
    req.log.error(err);
    return void res.status(500).json({ error: "Server error" });
  }
});

// GET /api/cars/:id — public
router.get("/cars/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [car] = await db.select().from(carsTable).where(eq(carsTable.id, id)).limit(1);
    if (!car) return void res.status(404).json({ error: "Car not found" });
    return void res.json(formatCar(car));
  } catch (err) {
    return void res.status(404).json({ error: "Car not found" });
  }
});

// POST /api/cars — admin only
router.post("/cars", requireAdmin, async (req, res) => {
  try {
    const { name, model, year, price, category, description, imageUrl, range, topSpeed, acceleration, available } =
      req.body as {
        name: string;
        model: string;
        year: number;
        price: number;
        category: string;
        description?: string;
        imageUrl: string;
        range?: string;
        topSpeed?: string;
        acceleration?: string;
        available?: boolean;
      };

    const [car] = await db
      .insert(carsTable)
      .values({
        name,
        model,
        year,
        price: price.toString(),
        category,
        description,
        imageUrl,
        range,
        topSpeed,
        acceleration,
        available: available ?? true,
      })
      .returning();

    return void res.status(201).json(formatCar(car));
  } catch (err) {
    req.log.error(err);
    return void res.status(400).json({ error: "Failed to create car" });
  }
});

// PUT /api/cars/:id — admin only
router.put("/cars/:id", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const updates = { ...req.body } as Record<string, unknown>;
    if (typeof updates.price === "number") {
      updates.price = updates.price.toString();
    }

    const [car] = await db
      .update(carsTable)
      .set(updates)
      .where(eq(carsTable.id, id))
      .returning();

    if (!car) return void res.status(404).json({ error: "Car not found" });
    return void res.json(formatCar(car));
  } catch (err) {
    req.log.error(err);
    return void res.status(400).json({ error: "Failed to update car" });
  }
});

// DELETE /api/cars/:id — admin only
router.delete("/cars/:id", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(carsTable).where(eq(carsTable.id, id));
    return void res.json({ message: "Car deleted" });
  } catch (err) {
    req.log.error(err);
    return void res.status(400).json({ error: "Failed to delete car" });
  }
});

export default router;
