import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../middlewares/auth";

const router = Router();

function sanitizeUser(user: typeof usersTable.$inferSelect) {
  const { passwordHash: _, ...safe } = user;
  return { ...safe, balance: parseFloat(safe.balance as unknown as string) };
}

// GET /api/users — admin only
router.get("/users", requireAdmin, async (req, res) => {
  try {
    const users = await db.select().from(usersTable).orderBy(usersTable.createdAt);
    return void res.json(users.map(sanitizeUser));
  } catch (err) {
    req.log.error(err);
    return void res.status(500).json({ error: "Server error" });
  }
});

// GET /api/users/:id
router.get("/users/:id", requireAuth, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    // Users can only get themselves unless admin
    const [user] = await db
      .select({ role: usersTable.role })
      .from(usersTable)
      .where(eq(usersTable.id, req.session.userId!))
      .limit(1);

    if (!user) return void res.status(401).json({ error: "Unauthorized" });
    if (user.role !== "admin" && id !== req.session.userId) {
      return void res.status(403).json({ error: "Forbidden" });
    }

    const [target] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, id))
      .limit(1);

    if (!target) return void res.status(404).json({ error: "User not found" });
    return void res.json(sanitizeUser(target));
  } catch (err) {
    req.log.error(err);
    return void res.status(500).json({ error: "Server error" });
  }
});

// PUT /api/users/:id — admin only
router.put("/users/:id", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { firstName, lastName, email, role, status, balance } = req.body as {
      firstName?: string;
      lastName?: string;
      email?: string;
      role?: "user" | "admin";
      status?: "active" | "suspended" | "pending";
      balance?: number;
    };

    const updates: Partial<typeof usersTable.$inferInsert> = {};
    if (firstName !== undefined) updates.firstName = firstName;
    if (lastName !== undefined) updates.lastName = lastName;
    if (email !== undefined) updates.email = email;
    if (role !== undefined) updates.role = role;
    if (status !== undefined) updates.status = status;
    if (balance !== undefined) updates.balance = balance.toString();

    const [updated] = await db
      .update(usersTable)
      .set(updates)
      .where(eq(usersTable.id, id))
      .returning();

    if (!updated) return void res.status(404).json({ error: "User not found" });
    return void res.json(sanitizeUser(updated));
  } catch (err) {
    req.log.error(err);
    return void res.status(500).json({ error: "Server error" });
  }
});

// DELETE /api/users/:id — admin only
router.delete("/users/:id", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(usersTable).where(eq(usersTable.id, id));
    return void res.json({ message: "User deleted" });
  } catch (err) {
    req.log.error(err);
    return void res.status(500).json({ error: "Server error" });
  }
});

export default router;
