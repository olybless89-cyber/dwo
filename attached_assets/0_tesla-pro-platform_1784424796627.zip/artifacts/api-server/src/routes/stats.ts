import { Router } from "express";
import { db, usersTable, ordersTable, investmentsTable, transactionsTable } from "@workspace/db";
import { eq, count, sum, gte } from "drizzle-orm";
import { requireAdmin } from "../middlewares/auth";

const router = Router();

// GET /api/stats/overview — admin only
router.get("/stats/overview", requireAdmin, async (req, res) => {
  try {
    const [totalUsersRow] = await db.select({ cnt: count() }).from(usersTable);
    const [totalOrdersRow] = await db.select({ cnt: count() }).from(ordersTable);
    const [pendingOrdersRow] = await db
      .select({ cnt: count() })
      .from(ordersTable)
      .where(eq(ordersTable.status, "pending"));
    const [activeInvestmentsRow] = await db
      .select({ cnt: count() })
      .from(investmentsTable)
      .where(eq(investmentsTable.status, "active"));
    const [pendingTransactionsRow] = await db
      .select({ cnt: count() })
      .from(transactionsTable)
      .where(eq(transactionsTable.status, "pending"));
    const [totalRevenueRow] = await db
      .select({ total: sum(ordersTable.amount) })
      .from(ordersTable)
      .where(eq(ordersTable.status, "delivered"));
    const [totalInvestedRow] = await db
      .select({ total: sum(investmentsTable.amount) })
      .from(investmentsTable)
      .where(eq(investmentsTable.status, "active"));

    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    const [newUsersRow] = await db
      .select({ cnt: count() })
      .from(usersTable)
      .where(gte(usersTable.createdAt, oneWeekAgo));

    return void res.json({
      totalUsers: totalUsersRow?.cnt ?? 0,
      totalRevenue: parseFloat((totalRevenueRow?.total ?? "0") as string),
      pendingTransactions: pendingTransactionsRow?.cnt ?? 0,
      activeInvestments: activeInvestmentsRow?.cnt ?? 0,
      totalOrders: totalOrdersRow?.cnt ?? 0,
      pendingOrders: pendingOrdersRow?.cnt ?? 0,
      newUsersThisWeek: newUsersRow?.cnt ?? 0,
      totalInvested: parseFloat((totalInvestedRow?.total ?? "0") as string),
    });
  } catch (err) {
    req.log.error(err);
    return void res.status(500).json({ error: "Server error" });
  }
});

export default router;
