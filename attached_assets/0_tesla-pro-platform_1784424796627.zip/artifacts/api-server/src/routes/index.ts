import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import usersRouter from "./users";
import carsRouter from "./cars";
import ordersRouter from "./orders";
import investmentsRouter from "./investments";
import walletRouter from "./wallet";
import transactionsRouter from "./transactions";
import giveawaysRouter from "./giveaways";
import statsRouter from "./stats";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(usersRouter);
router.use(carsRouter);
router.use(ordersRouter);
router.use(investmentsRouter);
router.use(walletRouter);
router.use(transactionsRouter);
router.use(giveawaysRouter);
router.use(statsRouter);

export default router;
