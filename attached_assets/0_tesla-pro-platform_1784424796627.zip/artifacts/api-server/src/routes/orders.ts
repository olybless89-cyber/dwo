import { Router } from "express";
import { db, ordersTable, carsTable, usersTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../middlewares/auth";

const router = Router();

function formatOrder(order: typeof ordersTable.$inferSelect & {
  car?: typeof carsTable.$inferSelect | null;
  user?: Partial<typeof usersTable.$inferSelect> | null;
}) {
  return {
    ...order,
    amount: parseFloat(order.amount as unknown as string),
    car: order.car ? { ...order.car, price: parseFloat(order.car.price as unknown as string) } : null,
    user: order.user ?? null,
  };
}

// GET /api/orders
router.get("/orders", requireAuth, async (req, res) => {
  try {
    const currentUser = await db
      .select({ role: usersTable.role })
      .from(usersTable)
      .where(eq(usersTable.id, req.session.userId!))
      .limit(1);

    const isAdmin = currentUser[0]?.role === "admin";

    const rows = await db
      .select({
        order: ordersTable,
        car: carsTable,
        userFirstName: usersTable.firstName,
        userLastName: usersTable.lastName,
        userEmail: usersTable.email,
        userId: usersTable.id,
      })
      .from(ordersTable)
      .leftJoin(carsTable, eq(ordersTable.carId, carsTable.id))
      .leftJoin(usersTable, eq(ordersTable.userId, usersTable.id))
      .where(isAdmin ? undefined : eq(ordersTable.userId, req.session.userId!))
      .orderBy(desc(ordersTable.createdAt));

    const orders = rows.map(({ order, car, userFirstName, userLastName, userEmail, userId }) => ({
      ...order,
      amount: parseFloat(order.amount as unknown as string),
      car: car ? { ...car, price: parseFloat(car.price as unknown as string) } : null,
      user: userId ? { id: userId, firstName: userFirstName, lastName: userLastName, email: userEmail } : null,
    }));

    return void res.json(orders);
  } catch (err) {
    req.log.error(err);
    return void res.status(500).json({ error: "Server error" });
  }
});

// POST /api/orders — create a car purchase
router.post("/orders", requireAuth, async (req, res) => {
  try {
    const { carId, paymentMethod, notes } = req.body as {
      carId: number;
      paymentMethod: string;
      notes?: string;
    };

    const [car] = await db
      .select()
      .from(carsTable)
      .where(eq(carsTable.id, carId))
      .limit(1);

    if (!car) return void res.status(404).json({ error: "Car not found" });
    if (!car.available) return void res.status(400).json({ error: "Car not available" });

    const [order] = await db
      .insert(ordersTable)
      .values({
        userId: req.session.userId!,
        carId,
        amount: car.price,
        paymentMethod,
        notes,
      })
      .returning();

    return void res.status(201).json({
      ...order,
      amount: parseFloat(order.amount as unknown as string),
      car: { ...car, price: parseFloat(car.price as unknown as string) },
    });
  } catch (err) {
    req.log.error(err);
    return void res.status(400).json({ error: "Failed to create order" });
  }
});

// GET /api/orders/:id
router.get("/orders/:id", requireAuth, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const currentUser = await db
      .select({ role: usersTable.role })
      .from(usersTable)
      .where(eq(usersTable.id, req.session.userId!))
      .limit(1);
    const isAdmin = currentUser[0]?.role === "admin";

    const [row] = await db
      .select({ order: ordersTable, car: carsTable })
      .from(ordersTable)
      .leftJoin(carsTable, eq(ordersTable.carId, carsTable.id))
      .where(eq(ordersTable.id, id))
      .limit(1);

    if (!row) return void res.status(404).json({ error: "Order not found" });
    if (!isAdmin && row.order.userId !== req.session.userId) {
      return void res.status(403).json({ error: "Forbidden" });
    }

    return void res.json(formatOrder({ ...row.order, car: row.car }));
  } catch (err) {
    return void res.status(404).json({ error: "Order not found" });
  }
});

// PUT /api/orders/:id — admin only
router.put("/orders/:id", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { status, notes } = req.body as {
      status?: "pending" | "confirmed" | "processing" | "delivered" | "cancelled";
      notes?: string;
    };

    const updates: Partial<typeof ordersTable.$inferInsert> = {};
    if (status) updates.status = status;
    if (notes !== undefined) updates.notes = notes;

    const [order] = await db
      .update(ordersTable)
      .set(updates)
      .where(eq(ordersTable.id, id))
      .returning();

    if (!order) return void res.status(404).json({ error: "Order not found" });
    return void res.json({ ...order, amount: parseFloat(order.amount as unknown as string) });
  } catch (err) {
    req.log.error(err);
    return void res.status(400).json({ error: "Failed to update order" });
  }
});

export default router;
