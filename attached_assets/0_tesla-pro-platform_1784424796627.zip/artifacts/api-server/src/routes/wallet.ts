import { Router } from "express";
import { db, usersTable, transactionsTable } from "@workspace/db";
import { eq, and, sum, count } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router = Router();

// GET /api/wallet
router.get("/wallet", requireAuth, async (req, res) => {
  try {
    const userId = req.session.userId!;

    const [user] = await db
      .select({ balance: usersTable.balance })
      .from(usersTable)
      .where(eq(usersTable.id, userId))
      .limit(1);

    if (!user) return void res.status(404).json({ error: "User not found" });

    // Calculate totals from approved transactions
    const [depositTotal] = await db
      .select({ total: sum(transactionsTable.amount) })
      .from(transactionsTable)
      .where(
        and(
          eq(transactionsTable.userId, userId),
          eq(transactionsTable.type, "deposit"),
          eq(transactionsTable.status, "approved"),
        ),
      );

    const [withdrawTotal] = await db
      .select({ total: sum(transactionsTable.amount) })
      .from(transactionsTable)
      .where(
        and(
          eq(transactionsTable.userId, userId),
          eq(transactionsTable.type, "withdrawal"),
          eq(transactionsTable.status, "approved"),
        ),
      );

    const [pendingCount] = await db
      .select({ cnt: count() })
      .from(transactionsTable)
      .where(
        and(
          eq(transactionsTable.userId, userId),
          eq(transactionsTable.status, "pending"),
        ),
      );

    return void res.json({
      balance: parseFloat(user.balance as unknown as string),
      totalDeposited: parseFloat((depositTotal?.total ?? "0") as string),
      totalWithdrawn: parseFloat((withdrawTotal?.total ?? "0") as string),
      totalInvested: 0,
      pendingTransactions: pendingCount?.cnt ?? 0,
    });
  } catch (err) {
    req.log.error(err);
    return void res.status(500).json({ error: "Server error" });
  }
});

// POST /api/wallet/deposit
router.post("/wallet/deposit", requireAuth, async (req, res) => {
  try {
    const { amount, method, reference } = req.body as {
      amount: number;
      method: string;
      reference?: string;
    };

    if (!amount || amount <= 0) return void res.status(400).json({ error: "Invalid amount" });
    if (!method) return void res.status(400).json({ error: "Payment method required" });

    const [tx] = await db
      .insert(transactionsTable)
      .values({
        userId: req.session.userId!,
        type: "deposit",
        amount: amount.toString(),
        method,
        reference,
        status: "pending",
      })
      .returning();

    return void res.status(201).json({
      ...tx,
      amount: parseFloat(tx.amount as unknown as string),
      user: null,
    });
  } catch (err) {
    req.log.error(err);
    return void res.status(400).json({ error: "Failed to create deposit request" });
  }
});

// POST /api/wallet/withdraw
router.post("/wallet/withdraw", requireAuth, async (req, res) => {
  try {
    const { amount, method, notes } = req.body as {
      amount: number;
      method: string;
      notes?: string;
    };

    if (!amount || amount <= 0) return void res.status(400).json({ error: "Invalid amount" });
    if (!method) return void res.status(400).json({ error: "Withdrawal method required" });

    const [user] = await db
      .select({ balance: usersTable.balance })
      .from(usersTable)
      .where(eq(usersTable.id, req.session.userId!))
      .limit(1);

    const currentBalance = parseFloat(user?.balance as unknown as string ?? "0");
    if (currentBalance < amount) {
      return void res.status(400).json({ error: "Insufficient balance" });
    }

    const [tx] = await db
      .insert(transactionsTable)
      .values({
        userId: req.session.userId!,
        type: "withdrawal",
        amount: amount.toString(),
        method,
        notes,
        status: "pending",
      })
      .returning();

    return void res.status(201).json({
      ...tx,
      amount: parseFloat(tx.amount as unknown as string),
      user: null,
    });
  } catch (err) {
    req.log.error(err);
    return void res.status(400).json({ error: "Failed to create withdrawal request" });
  }
});

export default router;
