import { Router } from "express";
import { db, investmentsTable, usersTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../middlewares/auth";

const router = Router();

const PLAN_DAILY_RETURNS: Record<string, number> = {
  fan_explorer: 8,
  fan_insider: 15,
  fan_founder: 25,
};

const PLAN_MIN: Record<string, number> = {
  fan_explorer: 5000,
  fan_insider: 8500,
  fan_founder: 15000,
};

function formatInvestment(inv: typeof investmentsTable.$inferSelect & {
  user?: Partial<typeof usersTable.$inferSelect> | null;
}) {
  return {
    ...inv,
    amount: parseFloat(inv.amount as unknown as string),
    dailyReturn: parseFloat(inv.dailyReturn as unknown as string),
    totalEarned: parseFloat(inv.totalEarned as unknown as string),
    user: inv.user ?? null,
  };
}

// GET /api/investments
router.get("/investments", requireAuth, async (req, res) => {
  try {
    const [currentUser] = await db
      .select({ role: usersTable.role })
      .from(usersTable)
      .where(eq(usersTable.id, req.session.userId!))
      .limit(1);

    const isAdmin = currentUser?.role === "admin";

    const rows = await db
      .select({
        investment: investmentsTable,
        userFirstName: usersTable.firstName,
        userLastName: usersTable.lastName,
        userEmail: usersTable.email,
        userId: usersTable.id,
      })
      .from(investmentsTable)
      .leftJoin(usersTable, eq(investmentsTable.userId, usersTable.id))
      .where(isAdmin ? undefined : eq(investmentsTable.userId, req.session.userId!))
      .orderBy(desc(investmentsTable.createdAt));

    const investments = rows.map(({ investment, userFirstName, userLastName, userEmail, userId }) =>
      formatInvestment({
        ...investment,
        user: userId ? { id: userId, firstName: userFirstName, lastName: userLastName, email: userEmail } : null,
      })
    );

    return void res.json(investments);
  } catch (err) {
    req.log.error(err);
    return void res.status(500).json({ error: "Server error" });
  }
});

// POST /api/investments
router.post("/investments", requireAuth, async (req, res) => {
  try {
    const { plan, amount } = req.body as {
      plan: "fan_explorer" | "fan_insider" | "fan_founder";
      amount: number;
    };

    const minAmount = PLAN_MIN[plan];
    if (!minAmount) return void res.status(400).json({ error: "Invalid plan" });
    if (amount < minAmount) {
      return void res.status(400).json({ error: `Minimum investment for this plan is $${minAmount.toLocaleString()}` });
    }

    const dailyReturn = PLAN_DAILY_RETURNS[plan];

    const [investment] = await db
      .insert(investmentsTable)
      .values({
        userId: req.session.userId!,
        plan,
        amount: amount.toString(),
        dailyReturn: dailyReturn.toString(),
      })
      .returning();

    return void res.status(201).json(formatInvestment({ ...investment, user: null }));
  } catch (err) {
    req.log.error(err);
    return void res.status(400).json({ error: "Failed to create investment" });
  }
});

// PUT /api/investments/:id — admin only
router.put("/investments/:id", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { status, totalEarned } = req.body as {
      status?: "pending" | "active" | "completed" | "cancelled";
      totalEarned?: number;
    };

    const updates: Partial<typeof investmentsTable.$inferInsert> = {};
    if (status) updates.status = status;
    if (totalEarned !== undefined) updates.totalEarned = totalEarned.toString();

    const [investment] = await db
      .update(investmentsTable)
      .set(updates)
      .where(eq(investmentsTable.id, id))
      .returning();

    if (!investment) return void res.status(404).json({ error: "Investment not found" });
    return void res.json(formatInvestment({ ...investment, user: null }));
  } catch (err) {
    req.log.error(err);
    return void res.status(400).json({ error: "Failed to update investment" });
  }
});

export default router;
