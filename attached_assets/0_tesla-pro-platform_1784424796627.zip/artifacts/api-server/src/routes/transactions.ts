import { Router } from "express";
import { db, transactionsTable, usersTable } from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../middlewares/auth";

const router = Router();

function formatTx(tx: typeof transactionsTable.$inferSelect & {
  user?: Partial<typeof usersTable.$inferSelect> | null;
}) {
  return {
    ...tx,
    amount: parseFloat(tx.amount as unknown as string),
    user: tx.user ?? null,
  };
}

// GET /api/transactions
router.get("/transactions", requireAuth, async (req, res) => {
  try {
    const [currentUser] = await db
      .select({ role: usersTable.role })
      .from(usersTable)
      .where(eq(usersTable.id, req.session.userId!))
      .limit(1);

    const isAdmin = currentUser?.role === "admin";

    const rows = await db
      .select({
        tx: transactionsTable,
        userFirstName: usersTable.firstName,
        userLastName: usersTable.lastName,
        userEmail: usersTable.email,
        userId: usersTable.id,
      })
      .from(transactionsTable)
      .leftJoin(usersTable, eq(transactionsTable.userId, usersTable.id))
      .where(isAdmin ? undefined : eq(transactionsTable.userId, req.session.userId!))
      .orderBy(desc(transactionsTable.createdAt));

    const txs = rows.map(({ tx, userFirstName, userLastName, userEmail, userId }) =>
      formatTx({
        ...tx,
        user: userId ? { id: userId, firstName: userFirstName, lastName: userLastName, email: userEmail } : null,
      })
    );

    return void res.json(txs);
  } catch (err) {
    req.log.error(err);
    return void res.status(500).json({ error: "Server error" });
  }
});

// PUT /api/transactions/:id — admin only
router.put("/transactions/:id", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { status, notes } = req.body as {
      status: "approved" | "rejected";
      notes?: string;
    };

    if (!["approved", "rejected"].includes(status)) {
      return void res.status(400).json({ error: "Invalid status" });
    }

    const [existing] = await db
      .select()
      .from(transactionsTable)
      .where(eq(transactionsTable.id, id))
      .limit(1);

    if (!existing) return void res.status(404).json({ error: "Transaction not found" });
    if (existing.status !== "pending") {
      return void res.status(400).json({ error: "Transaction already processed" });
    }

    // If approving, update user balance
    if (status === "approved") {
      const amount = parseFloat(existing.amount as unknown as string);
      if (existing.type === "deposit") {
        await db
          .update(usersTable)
          .set({
            balance: sql`${usersTable.balance} + ${amount}`,
          })
          .where(eq(usersTable.id, existing.userId));
      } else if (existing.type === "withdrawal") {
        // Check balance first
        const [user] = await db
          .select({ balance: usersTable.balance })
          .from(usersTable)
          .where(eq(usersTable.id, existing.userId))
          .limit(1);

        const currentBalance = parseFloat(user?.balance as unknown as string ?? "0");
        if (currentBalance < amount) {
          return void res.status(400).json({ error: "Insufficient user balance" });
        }

        await db
          .update(usersTable)
          .set({
            balance: sql`${usersTable.balance} - ${amount}`,
          })
          .where(eq(usersTable.id, existing.userId));
      }
    }

    const [updated] = await db
      .update(transactionsTable)
      .set({ status, notes: notes ?? existing.notes })
      .where(eq(transactionsTable.id, id))
      .returning();

    return void res.json(formatTx({ ...updated, user: null }));
  } catch (err) {
    req.log.error(err);
    return void res.status(400).json({ error: "Failed to update transaction" });
  }
});

export default router;
