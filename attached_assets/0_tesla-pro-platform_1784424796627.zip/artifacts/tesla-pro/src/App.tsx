import { ReactNode } from "react";
import { Route, Switch, Router as WouterRouter, useLocation, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { LoadingSpinner } from "@/components/LoadingSpinner";

// Layouts
import { MainLayout } from "@/layouts/MainLayout";
import { DashboardLayout } from "@/layouts/DashboardLayout";

// Public Pages
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import Shop from "@/pages/Shop";
import Giveaways from "@/pages/Giveaways";
import Membership from "@/pages/Membership";

// Dashboard Pages
import DashboardOverview from "@/pages/dashboard/Overview";
import DashboardWallet from "@/pages/dashboard/Wallet";
import DashboardInvestments from "@/pages/dashboard/Investments";
import DashboardOrders from "@/pages/dashboard/Orders";

// Admin Pages
import AdminOverview from "@/pages/admin/Overview";
import AdminUsers from "@/pages/admin/Users";
import AdminOrders from "@/pages/admin/Orders";
import AdminInvestments from "@/pages/admin/Investments";
import AdminTransactions from "@/pages/admin/Transactions";
import AdminGiveaways from "@/pages/admin/Giveaways";
import AdminCars from "@/pages/admin/Cars";

import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

function ProtectedRoute({ component: Component, adminOnly = false }: { component: any; adminOnly?: boolean }) {
  const { isAuthenticated, isLoading, isAdmin } = useAuth();
  const [location] = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <LoadingSpinner />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to={`/login?redirect=${encodeURIComponent(location)}`} />;
  }

  if (adminOnly && !isAdmin) {
    return <Redirect to="/dashboard" />;
  }

  return (
    <DashboardLayout admin={adminOnly}>
      <Component />
    </DashboardLayout>
  );
}

function PublicRoute({ component: Component, withLayout = true }: { component: any; withLayout?: boolean }) {
  if (!withLayout) return <Component />;
  
  return (
    <MainLayout>
      <Component />
    </MainLayout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={() => <PublicRoute component={Home} />} />
      <Route path="/login" component={() => <PublicRoute component={Login} />} />
      <Route path="/register" component={() => <PublicRoute component={Register} />} />
      <Route path="/shop" component={() => <PublicRoute component={Shop} />} />
      <Route path="/giveaways" component={() => <PublicRoute component={Giveaways} />} />
      <Route path="/membership" component={() => <PublicRoute component={Membership} />} />

      {/* Dashboard Routes */}
      <Route path="/dashboard" component={() => <ProtectedRoute component={DashboardOverview} />} />
      <Route path="/dashboard/wallet" component={() => <ProtectedRoute component={DashboardWallet} />} />
      <Route path="/dashboard/investments" component={() => <ProtectedRoute component={DashboardInvestments} />} />
      <Route path="/dashboard/orders" component={() => <ProtectedRoute component={DashboardOrders} />} />

      {/* Admin Routes */}
      <Route path="/admin" component={() => <ProtectedRoute component={AdminOverview} adminOnly />} />
      <Route path="/admin/users" component={() => <ProtectedRoute component={AdminUsers} adminOnly />} />
      <Route path="/admin/orders" component={() => <ProtectedRoute component={AdminOrders} adminOnly />} />
      <Route path="/admin/investments" component={() => <ProtectedRoute component={AdminInvestments} adminOnly />} />
      <Route path="/admin/transactions" component={() => <ProtectedRoute component={AdminTransactions} adminOnly />} />
      <Route path="/admin/giveaways" component={() => <ProtectedRoute component={AdminGiveaways} adminOnly />} />
      <Route path="/admin/cars" component={() => <ProtectedRoute component={AdminCars} adminOnly />} />

      <Route component={() => <PublicRoute component={NotFound} />} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
