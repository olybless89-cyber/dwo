import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ChevronRight, ShieldCheck, Zap, TrendingUp } from "lucide-react";

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative w-full h-[90vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-background/20 via-background/60 to-background z-10" />
          <img 
            src="https://digitalassets.tesla.com/tesla-contents/image/upload/h_1800,w_2880,c_fit,f_auto,q_auto:best/Homepage-Model-S-Desktop-LHD-6.22" 
            alt="Tesla Model S" 
            className="w-full h-full object-cover object-center opacity-40"
          />
        </div>
        <div className="container relative z-10 mx-auto px-4 text-center flex flex-col items-center">
          <h1 className="text-5xl md:text-7xl font-bold tracking-tighter mb-6">
            The Future of <span className="text-primary">Ownership</span>
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mb-10">
            Exclusive investments, premium vehicle marketplace, and VIP rewards. Welcome to the Tesla Pro Platform.
          </p>
          <div className="flex gap-4">
            <Link href="/register">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground text-lg px-8 signal-glow">
                Join Pro Access
              </Button>
            </Link>
            <Link href="/shop">
              <Button size="lg" variant="outline" className="text-lg px-8 glass border-white/10 hover:bg-white/10">
                Explore Fleet
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats/Features Section */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="glass p-8 rounded-xl border border-white/5 flex flex-col items-center text-center">
              <TrendingUp className="h-12 w-12 text-primary mb-4" />
              <h3 className="text-xl font-bold mb-2">High-Yield Investments</h3>
              <p className="text-muted-foreground">Access exclusive fan investment plans yielding up to 25% daily returns.</p>
            </div>
            <div className="glass p-8 rounded-xl border border-white/5 flex flex-col items-center text-center">
              <Zap className="h-12 w-12 text-primary mb-4" />
              <h3 className="text-xl font-bold mb-2">Priority Vehicle Access</h3>
              <p className="text-muted-foreground">Skip the waitlist. Purchase exclusive and limited-edition models directly.</p>
            </div>
            <div className="glass p-8 rounded-xl border border-white/5 flex flex-col items-center text-center">
              <ShieldCheck className="h-12 w-12 text-primary mb-4" />
              <h3 className="text-xl font-bold mb-2">VIP Membership</h3>
              <p className="text-muted-foreground">Unlock premium giveaways, dedicated account management, and exclusive events.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Investment Plans */}
      <section className="py-24 bg-card/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold tracking-tighter mb-4">Pro Investment Plans</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Multiply your assets with our guaranteed return investment structures designed for our most dedicated supporters.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {/* Plan 1 */}
            <div className="glass rounded-xl p-8 border border-white/5 flex flex-col">
              <h3 className="text-2xl font-bold mb-2">Fan Explorer</h3>
              <div className="text-4xl font-bold mb-6">$5,000<span className="text-lg text-muted-foreground font-normal"> min</span></div>
              <ul className="space-y-4 mb-8 flex-1">
                <li className="flex items-center text-muted-foreground"><ChevronRight className="h-4 w-4 text-primary mr-2" /> 8% Daily Return</li>
                <li className="flex items-center text-muted-foreground"><ChevronRight className="h-4 w-4 text-primary mr-2" /> Basic Support</li>
                <li className="flex items-center text-muted-foreground"><ChevronRight className="h-4 w-4 text-primary mr-2" /> Standard Giveaways</li>
              </ul>
              <Link href="/register">
                <Button className="w-full glass border-white/10" variant="outline">Start Investing</Button>
              </Link>
            </div>
            
            {/* Plan 2 */}
            <div className="glass rounded-xl p-8 border border-primary/50 relative flex flex-col shadow-[0_0_30px_rgba(232,33,39,0.15)] transform md:-translate-y-4">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-bold tracking-wider">
                MOST POPULAR
              </div>
              <h3 className="text-2xl font-bold mb-2">Fan Insider</h3>
              <div className="text-4xl font-bold mb-6">$8,500<span className="text-lg text-muted-foreground font-normal"> min</span></div>
              <ul className="space-y-4 mb-8 flex-1">
                <li className="flex items-center text-muted-foreground"><ChevronRight className="h-4 w-4 text-primary mr-2" /> 15% Daily Return</li>
                <li className="flex items-center text-muted-foreground"><ChevronRight className="h-4 w-4 text-primary mr-2" /> Priority Support</li>
                <li className="flex items-center text-muted-foreground"><ChevronRight className="h-4 w-4 text-primary mr-2" /> Premium Giveaways</li>
              </ul>
              <Link href="/register">
                <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground signal-glow">Start Investing</Button>
              </Link>
            </div>
            
            {/* Plan 3 */}
            <div className="glass rounded-xl p-8 border border-white/5 flex flex-col">
              <h3 className="text-2xl font-bold mb-2">Fan Founder</h3>
              <div className="text-4xl font-bold mb-6">$15,000<span className="text-lg text-muted-foreground font-normal"> min</span></div>
              <ul className="space-y-4 mb-8 flex-1">
                <li className="flex items-center text-muted-foreground"><ChevronRight className="h-4 w-4 text-primary mr-2" /> 25% Daily Return</li>
                <li className="flex items-center text-muted-foreground"><ChevronRight className="h-4 w-4 text-primary mr-2" /> Dedicated Manager</li>
                <li className="flex items-center text-muted-foreground"><ChevronRight className="h-4 w-4 text-primary mr-2" /> VIP Event Access</li>
              </ul>
              <Link href="/register">
                <Button className="w-full glass border-white/10" variant="outline">Start Investing</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      {/* Fleet Teaser */}
      <section className="py-24 bg-background border-y border-white/5">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-5xl font-bold tracking-tighter mb-8">Exclusive Fleet Access</h2>
          <div className="flex justify-center gap-4 flex-wrap mb-10">
            <img src="https://digitalassets.tesla.com/tesla-contents/image/upload/f_auto,q_auto/Cybertruck-Hero-Desktop.jpg" className="w-64 h-40 object-cover rounded-lg border border-white/10 opacity-70 hover:opacity-100 transition-opacity" alt="Cybertruck" />
            <img src="https://digitalassets.tesla.com/tesla-contents/image/upload/h_1800,w_2880,c_fit,f_auto,q_auto:best/Homepage-Model-Y-Global-Desktop" className="w-64 h-40 object-cover rounded-lg border border-white/10 opacity-70 hover:opacity-100 transition-opacity" alt="Model Y" />
            <img src="https://digitalassets.tesla.com/tesla-contents/image/upload/h_1800,w_2880,c_fit,f_auto,q_auto:best/Homepage-Model-3-Desktop-LHD" className="w-64 h-40 object-cover rounded-lg border border-white/10 opacity-70 hover:opacity-100 transition-opacity" alt="Model 3" />
          </div>
          <Link href="/shop">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground signal-glow">View Inventory</Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
