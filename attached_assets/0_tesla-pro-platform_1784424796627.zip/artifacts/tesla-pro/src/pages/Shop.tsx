import { useState } from "react";
import { useListCars, useCreateOrder } from "@workspace/api-client-react";
import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Gauge, Zap, Battery } from "lucide-react";

export default function Shop() {
  const { data: cars, isLoading } = useListCars();
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [activeCategory, setActiveCategory] = useState<string>("All");
  const [selectedCar, setSelectedCar] = useState<any | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const createOrder = useCreateOrder();

  const handleBuyClick = (car: any) => {
    if (!isAuthenticated) {
      setLocation("/login");
      return;
    }
    setSelectedCar(car);
    setIsModalOpen(true);
  };

  const confirmPurchase = () => {
    if (!selectedCar) return;
    
    createOrder.mutate({
      data: { carId: selectedCar.id }
    }, {
      onSuccess: () => {
        toast({ title: "Order Placed", description: "Your car order has been successfully placed." });
        setIsModalOpen(false);
        setLocation("/dashboard/orders");
      },
      onError: (err: any) => {
        toast({
          title: "Order Failed",
          description: err.response?.data?.message || "Failed to process order.",
          variant: "destructive"
        });
      }
    });
  };

  const categories = ["All", ...Array.from(new Set(cars?.map(c => c.category) || []))];
  const filteredCars = cars?.filter(c => activeCategory === "All" || c.category === activeCategory) || [];

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-12 text-center">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tighter mb-4">Pro Marketplace</h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Exclusive access to premium inventory, limited editions, and priority delivery.
        </p>
      </div>

      <div className="flex justify-center gap-2 mb-10 flex-wrap">
        {categories.map(cat => (
          <Button
            key={cat}
            variant={activeCategory === cat ? "default" : "outline"}
            className={activeCategory === cat ? "bg-primary signal-glow" : "glass border-white/10"}
            onClick={() => setActiveCategory(cat)}
          >
            {cat}
          </Button>
        ))}
      </div>

      {isLoading ? (
        <LoadingSpinner />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredCars.map(car => (
            <Card key={car.id} className="glass border-white/5 overflow-hidden flex flex-col group">
              <div className="relative h-64 overflow-hidden bg-black/40">
                <img 
                  src={car.imageUrl || "https://digitalassets.tesla.com/tesla-contents/image/upload/h_1800,w_2880,c_fit,f_auto,q_auto:best/Homepage-Model-S-Desktop-LHD-6.22"} 
                  alt={car.name} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                {!car.available && (
                  <div className="absolute inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center">
                    <Badge variant="destructive" className="text-lg py-1 px-4">SOLD OUT</Badge>
                  </div>
                )}
                {car.available && (
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-primary hover:bg-primary text-white">Available</Badge>
                  </div>
                )}
              </div>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-2xl">{car.name}</CardTitle>
                    <p className="text-muted-foreground">{car.year} {car.model}</p>
                  </div>
                  <div className="text-xl font-bold">${car.price.toLocaleString()}</div>
                </div>
              </CardHeader>
              <CardContent className="flex-1">
                <div className="grid grid-cols-3 gap-4 mb-4">
                  {car.range && (
                    <div className="text-center p-2 rounded-lg bg-white/5 border border-white/5">
                      <Battery className="w-5 h-5 mx-auto mb-1 text-primary" />
                      <div className="text-xs font-medium">{car.range}</div>
                      <div className="text-[10px] text-muted-foreground">Range</div>
                    </div>
                  )}
                  {car.acceleration && (
                    <div className="text-center p-2 rounded-lg bg-white/5 border border-white/5">
                      <Zap className="w-5 h-5 mx-auto mb-1 text-primary" />
                      <div className="text-xs font-medium">{car.acceleration}</div>
                      <div className="text-[10px] text-muted-foreground">0-60 mph</div>
                    </div>
                  )}
                  {car.topSpeed && (
                    <div className="text-center p-2 rounded-lg bg-white/5 border border-white/5">
                      <Gauge className="w-5 h-5 mx-auto mb-1 text-primary" />
                      <div className="text-xs font-medium">{car.topSpeed}</div>
                      <div className="text-[10px] text-muted-foreground">Top Speed</div>
                    </div>
                  )}
                </div>
                <p className="text-sm text-muted-foreground line-clamp-2">{car.description}</p>
              </CardContent>
              <CardFooter>
                <Button 
                  className="w-full bg-primary hover:bg-primary/90 signal-glow" 
                  disabled={!car.available}
                  onClick={() => handleBuyClick(car)}
                >
                  Buy Now
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="glass border-white/10 sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirm Purchase</DialogTitle>
            <DialogDescription>
              You are about to reserve this vehicle.
            </DialogDescription>
          </DialogHeader>
          {selectedCar && (
            <div className="py-4">
              <div className="flex justify-between mb-2">
                <span className="text-muted-foreground">Vehicle:</span>
                <span className="font-medium">{selectedCar.year} {selectedCar.name}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-muted-foreground">Price:</span>
                <span className="font-bold">${selectedCar.price.toLocaleString()}</span>
              </div>
              <div className="text-xs text-muted-foreground mt-4 p-3 bg-white/5 rounded-md border border-white/5">
                By confirming, a purchase order will be created in your account. Your dedicated account manager will contact you for payment processing.
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" className="glass border-white/10" onClick={() => setIsModalOpen(false)}>Cancel</Button>
            <Button onClick={confirmPurchase} disabled={createOrder.isPending} className="bg-primary hover:bg-primary/90 signal-glow">
              {createOrder.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Confirm Reservation
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
