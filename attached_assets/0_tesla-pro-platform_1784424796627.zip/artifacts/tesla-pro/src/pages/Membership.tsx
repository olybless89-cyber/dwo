import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ChevronRight, ShieldCheck, Zap, TrendingUp, CheckCircle2 } from "lucide-react";

export default function Membership() {
  return (
    <div className="flex flex-col min-h-[calc(100vh-4rem)]">
      {/* Hero */}
      <section className="py-24 bg-background relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/10 rounded-full blur-[120px] pointer-events-none" />
        <div className="container relative z-10 mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-7xl font-bold tracking-tighter mb-6">
            Elite Access. <span className="text-primary">Unmatched Value.</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10">
            Tesla Pro is an invite-only tier for the most dedicated supporters. Access priority inventory, exclusive investment vehicles, and VIP experiences.
          </p>
          <Link href="/register">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground text-lg px-8 signal-glow">
              Apply for Membership
            </Button>
          </Link>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-24 bg-card/30 border-y border-white/5">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-16">Membership Benefits</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-5xl mx-auto">
            
            <div className="flex gap-6">
              <div className="shrink-0">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
                  <Zap className="h-6 w-6 text-primary" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Priority Vehicle Access</h3>
                <p className="text-muted-foreground">Skip the queue for new models, limited editions, and exclusive configurations not available to the public. Secure your allocation immediately.</p>
              </div>
            </div>

            <div className="flex gap-6">
              <div className="shrink-0">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
                  <TrendingUp className="h-6 w-6 text-primary" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Fan Investment Plans</h3>
                <p className="text-muted-foreground">Participate in high-yield micro-investments designed exclusively for our community. Earn up to 25% daily returns backed by our robust financial framework.</p>
              </div>
            </div>

            <div className="flex gap-6">
              <div className="shrink-0">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
                  <ShieldCheck className="h-6 w-6 text-primary" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Dedicated Account Manager</h3>
                <p className="text-muted-foreground">Receive white-glove service. A dedicated representative will handle your vehicle orders, investments, and platform support.</p>
              </div>
            </div>

            <div className="flex gap-6">
              <div className="shrink-0">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
                  <CheckCircle2 className="h-6 w-6 text-primary" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">VIP Event Access</h3>
                <p className="text-muted-foreground">Invitations to exclusive launches, factory tours, and private networking events with other high-net-worth members.</p>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Tiers summary */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-8">Ready to elevate your portfolio?</h2>
          <p className="text-muted-foreground max-w-xl mx-auto mb-10">
            Membership is tied to your active investment tier. Start with the Explorer plan to unlock baseline access, or go straight to Founder for the complete VIP experience.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/register">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground signal-glow">
                Create Account
              </Button>
            </Link>
            <Link href="/shop">
              <Button size="lg" variant="outline" className="glass border-white/10">
                Browse Inventory First
              </Button>
            </Link>
          </div>
        </div>
      </section>

    </div>
  );
}
