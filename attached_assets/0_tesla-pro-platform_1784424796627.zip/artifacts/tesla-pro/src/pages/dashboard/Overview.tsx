import { useGetMe, useGetWallet } from "@workspace/api-client-react";
import { Link } from "wouter";
import { StatCard } from "@/components/StatCard";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { Button } from "@/components/ui/button";
import { Wallet, TrendingUp, ShoppingCart, ArrowUpRight, ArrowDownRight } from "lucide-react";

export default function Overview() {
  const { data: user, isLoading: userLoading } = useGetMe();
  const { data: wallet, isLoading: walletLoading } = useGetWallet();

  if (userLoading || walletLoading) return <LoadingSpinner />;

  return (
    <div className="p-6 md:p-10 space-y-8 max-w-6xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold tracking-tight mb-2">Welcome back, {user?.firstName}</h1>
        <p className="text-muted-foreground">Here's what's happening with your Tesla Pro account today.</p>
      </div>

      {/* Main Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass p-6 rounded-xl border border-primary/20 relative overflow-hidden group">
          <div className="absolute inset-0 bg-primary/5 group-hover:bg-primary/10 transition-colors" />
          <div className="relative z-10">
            <div className="flex items-center text-muted-foreground mb-4">
              <Wallet className="h-5 w-5 mr-2 text-primary" /> Total Balance
            </div>
            <div className="text-4xl font-bold mb-6">${wallet?.balance?.toLocaleString() ?? 0}</div>
            <div className="flex gap-3">
              <Link href="/dashboard/wallet">
                <Button size="sm" className="bg-primary hover:bg-primary/90 signal-glow">
                  <ArrowDownRight className="h-4 w-4 mr-1" /> Deposit
                </Button>
              </Link>
              <Link href="/dashboard/wallet">
                <Button size="sm" variant="outline" className="glass border-white/10 hover:bg-white/10">
                  <ArrowUpRight className="h-4 w-4 mr-1" /> Withdraw
                </Button>
              </Link>
            </div>
          </div>
        </div>

        <StatCard 
          title="Active Investments" 
          value={`$${wallet?.totalInvested?.toLocaleString() ?? 0}`} 
          icon={<TrendingUp />} 
          className="border-white/5"
        />
        <StatCard 
          title="Reward Points" 
          value={user?.rewardPoints?.toLocaleString() ?? 0} 
          icon={<ShoppingCart />} 
          description="Redeemable for merch"
          className="border-white/5"
        />
      </div>

      {/* Quick Actions / Navigation */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
        <div className="glass p-6 rounded-xl border border-white/5 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold mb-1">Explore Investment Plans</h3>
            <p className="text-sm text-muted-foreground">Earn up to 25% daily returns.</p>
          </div>
          <Link href="/dashboard/investments">
            <Button variant="outline" className="glass border-white/10">View Plans</Button>
          </Link>
        </div>
        
        <div className="glass p-6 rounded-xl border border-white/5 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold mb-1">Vehicle Pre-Orders</h3>
            <p className="text-sm text-muted-foreground">Check status of your fleet.</p>
          </div>
          <Link href="/dashboard/orders">
            <Button variant="outline" className="glass border-white/10">View Orders</Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
