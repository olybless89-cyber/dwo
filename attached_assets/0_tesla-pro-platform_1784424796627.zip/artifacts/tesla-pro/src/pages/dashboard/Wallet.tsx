import { useState } from "react";
import { useGetWallet, useListTransactions, useCreateDeposit, useCreateWithdrawal, getGetWalletQueryKey, getListTransactionsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { StatusBadge } from "@/components/StatusBadge";
import { Wallet, ArrowDownRight, ArrowUpRight, Loader2, Info } from "lucide-react";

export default function DashboardWallet() {
  const { data: wallet, isLoading: walletLoading } = useGetWallet();
  const { data: transactions, isLoading: txLoading } = useListTransactions();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [depositOpen, setDepositOpen] = useState(false);
  const [withdrawOpen, setWithdrawOpen] = useState(false);
  
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("crypto");
  const [reference, setReference] = useState("");

  const createDeposit = useCreateDeposit();
  const createWithdrawal = useCreateWithdrawal();

  const resetForm = () => {
    setAmount("");
    setMethod("crypto");
    setReference("");
  };

  const handleDeposit = () => {
    if (!amount || isNaN(Number(amount))) return;
    
    createDeposit.mutate({
      data: { amount: Number(amount), method, reference }
    }, {
      onSuccess: () => {
        toast({ title: "Deposit Requested", description: "Your deposit request is pending approval." });
        queryClient.invalidateQueries({ queryKey: getListTransactionsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetWalletQueryKey() });
        setDepositOpen(false);
        resetForm();
      },
      onError: (err: any) => {
        toast({ title: "Deposit Failed", description: err.response?.data?.message, variant: "destructive" });
      }
    });
  };

  const handleWithdrawal = () => {
    if (!amount || isNaN(Number(amount))) return;
    
    createWithdrawal.mutate({
      data: { amount: Number(amount), method }
    }, {
      onSuccess: () => {
        toast({ title: "Withdrawal Requested", description: "Your withdrawal request is pending processing." });
        queryClient.invalidateQueries({ queryKey: getListTransactionsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetWalletQueryKey() });
        setWithdrawOpen(false);
        resetForm();
      },
      onError: (err: any) => {
        toast({ title: "Withdrawal Failed", description: err.response?.data?.message, variant: "destructive" });
      }
    });
  };

  if (walletLoading || txLoading) return <LoadingSpinner />;

  return (
    <div className="p-6 md:p-10 max-w-6xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2">Wallet & Transactions</h1>
          <p className="text-muted-foreground">Manage your funds and view history.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="glass border-primary/20 md:col-span-2 relative overflow-hidden">
          <div className="absolute inset-0 bg-primary/5" />
          <CardHeader className="relative z-10 pb-2">
            <CardDescription>Available Balance</CardDescription>
            <CardTitle className="text-5xl font-bold text-white">${wallet?.balance?.toLocaleString() ?? 0}</CardTitle>
          </CardHeader>
          <CardContent className="relative z-10 mt-6 flex gap-4">
            <Button onClick={() => setDepositOpen(true)} className="bg-primary hover:bg-primary/90 signal-glow">
              <ArrowDownRight className="mr-2 h-4 w-4" /> Deposit Funds
            </Button>
            <Button onClick={() => setWithdrawOpen(true)} variant="outline" className="glass border-white/10 hover:bg-white/10">
              <ArrowUpRight className="mr-2 h-4 w-4" /> Withdraw
            </Button>
          </CardContent>
        </Card>

        <Card className="glass border-white/5">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Pending Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{wallet?.pendingTransactions ?? 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Awaiting admin approval</p>
          </CardContent>
        </Card>
      </div>

      <Card className="glass border-white/5">
        <CardHeader>
          <CardTitle>Transaction History</CardTitle>
        </CardHeader>
        <CardContent>
          {transactions?.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">No transactions found.</div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/5 hover:bg-transparent">
                    <TableHead>Date</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions?.map((tx) => (
                    <TableRow key={tx.id} className="border-white/5 hover:bg-white/5">
                      <TableCell>{format(new Date(tx.createdAt), 'MMM dd, yyyy')}</TableCell>
                      <TableCell className="capitalize font-medium">{tx.type}</TableCell>
                      <TableCell className="uppercase text-xs">{tx.method}</TableCell>
                      <TableCell className={`font-bold ${tx.type === 'deposit' ? 'text-emerald-500' : 'text-foreground'}`}>
                        {tx.type === 'deposit' ? '+' : '-'}${tx.amount.toLocaleString()}
                      </TableCell>
                      <TableCell><StatusBadge status={tx.status} /></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Deposit Modal */}
      <Dialog open={depositOpen} onOpenChange={setDepositOpen}>
        <DialogContent className="glass border-white/10 sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Deposit Funds</DialogTitle>
            <DialogDescription>Add funds to your account via Crypto or Wire Transfer.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Payment Method</Label>
              <Select value={method} onValueChange={setMethod}>
                <SelectTrigger className="bg-black/20 border-white/10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="crypto">USDT / Crypto</SelectItem>
                  <SelectItem value="wire">Wire Transfer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {method === 'crypto' && (
              <div className="bg-primary/10 border border-primary/20 p-4 rounded-lg flex items-start gap-3">
                <Info className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <div className="text-sm">
                  <p className="font-semibold text-primary mb-1">USDT (TRC20) Address:</p>
                  <code className="bg-black/50 p-1.5 rounded block text-xs break-all mb-2">TXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX</code>
                  <p className="text-muted-foreground text-xs">Send only USDT TRC20 to this address. Provide the transaction hash below.</p>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label>Amount (USD)</Label>
              <Input 
                type="number" 
                placeholder="5000" 
                value={amount} 
                onChange={(e) => setAmount(e.target.value)}
                className="bg-black/20 border-white/10"
              />
            </div>

            <div className="space-y-2">
              <Label>{method === 'crypto' ? 'Transaction Hash / TXID' : 'Reference Number'}</Label>
              <Input 
                placeholder="Required for verification" 
                value={reference} 
                onChange={(e) => setReference(e.target.value)}
                className="bg-black/20 border-white/10"
              />
            </div>
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="outline" className="glass border-white/10" onClick={() => {setDepositOpen(false); resetForm();}}>Cancel</Button>
            <Button onClick={handleDeposit} disabled={createDeposit.isPending} className="bg-primary hover:bg-primary/90 signal-glow">
              {createDeposit.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Submit Deposit
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Withdraw Modal */}
      <Dialog open={withdrawOpen} onOpenChange={setWithdrawOpen}>
        <DialogContent className="glass border-white/10 sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Withdraw Funds</DialogTitle>
            <DialogDescription>Available balance: ${wallet?.balance?.toLocaleString() ?? 0}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Withdrawal Method</Label>
              <Select value={method} onValueChange={setMethod}>
                <SelectTrigger className="bg-black/20 border-white/10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="crypto">USDT / Crypto</SelectItem>
                  <SelectItem value="wire">Wire Transfer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label>Amount (USD)</Label>
              <Input 
                type="number" 
                placeholder="1000" 
                value={amount} 
                onChange={(e) => setAmount(e.target.value)}
                className="bg-black/20 border-white/10"
              />
            </div>
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="outline" className="glass border-white/10" onClick={() => {setWithdrawOpen(false); resetForm();}}>Cancel</Button>
            <Button onClick={handleWithdrawal} disabled={createWithdrawal.isPending} className="bg-primary hover:bg-primary/90 signal-glow">
              {createWithdrawal.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Request Withdrawal
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
