import { useState } from "react";
import { useListInvestments, useCreateInvestment, getListInvestmentsQueryKey, getGetWalletQueryKey, useGetWallet } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { StatusBadge } from "@/components/StatusBadge";
import { ChevronRight, Loader2, AlertCircle } from "lucide-react";

const PLANS = [
  { id: "fan_explorer", name: "Fan Explorer", min: 5000, return: 8 },
  { id: "fan_insider", name: "Fan Insider", min: 8500, return: 15 },
  { id: "fan_founder", name: "Fan Founder", min: 15000, return: 25 },
];

export default function DashboardInvestments() {
  const { data: investments, isLoading } = useListInvestments();
  const { data: wallet } = useGetWallet();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [modalOpen, setModalOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [amount, setAmount] = useState("");

  const createInvestment = useCreateInvestment();

  const handleInvestClick = (plan: any) => {
    setSelectedPlan(plan);
    setAmount(plan.min.toString());
    setModalOpen(true);
  };

  const submitInvestment = () => {
    const numAmount = Number(amount);
    if (!selectedPlan || isNaN(numAmount) || numAmount < selectedPlan.min) {
      toast({ title: "Invalid amount", description: `Minimum for this plan is $${selectedPlan.min}`, variant: "destructive" });
      return;
    }

    createInvestment.mutate({
      data: { plan: selectedPlan.id as any, amount: numAmount }
    }, {
      onSuccess: () => {
        toast({ title: "Investment Created", description: "Your investment is now active." });
        queryClient.invalidateQueries({ queryKey: getListInvestmentsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetWalletQueryKey() });
        setModalOpen(false);
      },
      onError: (err: any) => {
        toast({ title: "Investment Failed", description: err.response?.data?.message, variant: "destructive" });
      }
    });
  };

  if (isLoading) return <LoadingSpinner />;

  return (
    <div className="p-6 md:p-10 max-w-6xl mx-auto space-y-12">
      <div>
        <h1 className="text-3xl font-bold tracking-tight mb-2">Investment Plans</h1>
        <p className="text-muted-foreground">Select a high-yield plan to start multiplying your assets.</p>
      </div>

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {PLANS.map((plan) => (
          <div key={plan.id} className="glass rounded-xl p-6 border border-white/5 flex flex-col relative overflow-hidden group">
            {plan.id === "fan_insider" && (
              <div className="absolute top-0 inset-x-0 h-1 bg-primary signal-glow" />
            )}
            <h3 className="text-xl font-bold mb-1">{plan.name}</h3>
            <div className="text-3xl font-bold mb-4">${plan.min.toLocaleString()}<span className="text-sm text-muted-foreground font-normal"> min</span></div>
            <div className="bg-white/5 rounded-lg p-3 mb-6 flex justify-between items-center border border-white/5">
              <span className="text-sm text-muted-foreground">Daily Return</span>
              <span className="font-bold text-emerald-500">{plan.return}%</span>
            </div>
            <Button 
              className={`w-full mt-auto ${plan.id === 'fan_insider' ? 'bg-primary hover:bg-primary/90 signal-glow' : 'glass border-white/10 hover:bg-white/10'}`}
              onClick={() => handleInvestClick(plan)}
            >
              Select Plan
            </Button>
          </div>
        ))}
      </div>

      {/* Active Investments */}
      <div>
        <h2 className="text-2xl font-bold mb-6">Your Investments</h2>
        {investments?.length === 0 ? (
          <div className="glass p-12 text-center rounded-xl border border-white/5">
            <p className="text-muted-foreground">You don't have any active investments yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {investments?.map(inv => {
              const plan = PLANS.find(p => p.id === inv.plan);
              return (
                <Card key={inv.id} className="glass border-white/5 flex flex-col">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{plan?.name || inv.plan}</CardTitle>
                      <StatusBadge status={inv.status} />
                    </div>
                    <CardDescription>Started {format(new Date(inv.createdAt), 'MMM dd, yyyy')}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1 mt-4 space-y-4">
                    <div className="flex justify-between items-end border-b border-white/5 pb-4">
                      <div className="text-sm text-muted-foreground">Principal</div>
                      <div className="font-bold">${inv.amount.toLocaleString()}</div>
                    </div>
                    <div className="flex justify-between items-end">
                      <div className="text-sm text-muted-foreground">Total Earned</div>
                      <div className="font-bold text-emerald-500">+${inv.totalEarned.toLocaleString()}</div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Invest Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="glass border-white/10 sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Start Investment</DialogTitle>
            <DialogDescription>You are selecting the {selectedPlan?.name} plan.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="flex justify-between text-sm bg-white/5 p-3 rounded-lg border border-white/5">
              <span className="text-muted-foreground">Available Wallet Balance:</span>
              <span className="font-bold">${wallet?.balance?.toLocaleString() ?? 0}</span>
            </div>
            
            <div className="space-y-2">
              <Label>Investment Amount (USD)</Label>
              <Input 
                type="number" 
                value={amount} 
                onChange={(e) => setAmount(e.target.value)}
                min={selectedPlan?.min}
                className="bg-black/20 border-white/10"
              />
              <p className="text-xs text-muted-foreground">Minimum deposit for this plan is ${selectedPlan?.min.toLocaleString()}</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" className="glass border-white/10" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button onClick={submitInvestment} disabled={createInvestment.isPending} className="bg-primary hover:bg-primary/90 signal-glow">
              {createInvestment.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Confirm Investment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
