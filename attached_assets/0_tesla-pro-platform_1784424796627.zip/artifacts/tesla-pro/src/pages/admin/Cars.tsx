import { useState } from "react";
import { useListCars, useCreateCar, useUpdateCar, useDeleteCar, getListCarsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { CarFront, Loader2, Plus, Edit2, Trash2 } from "lucide-react";

export default function AdminCars() {
  const { data: cars, isLoading } = useListCars();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingCar, setEditingCar] = useState<any>(null);
  
  const [formData, setFormData] = useState({
    name: "",
    model: "",
    year: new Date().getFullYear(),
    price: "",
    category: "",
    description: "",
    imageUrl: "",
    range: "",
    topSpeed: "",
    acceleration: "",
    available: true
  });
  
  const createCar = useCreateCar();
  const updateCar = useUpdateCar();
  const deleteCar = useDeleteCar();

  const openCreate = () => {
    setEditingCar(null);
    setFormData({
      name: "", model: "", year: new Date().getFullYear(), price: "", 
      category: "", description: "", imageUrl: "", range: "", 
      topSpeed: "", acceleration: "", available: true
    });
    setModalOpen(true);
  };

  const openEdit = (car: any) => {
    setEditingCar(car);
    setFormData({
      name: car.name, model: car.model, year: car.year, price: car.price.toString(), 
      category: car.category, description: car.description || "", imageUrl: car.imageUrl, 
      range: car.range || "", topSpeed: car.topSpeed || "", acceleration: car.acceleration || "", 
      available: car.available
    });
    setModalOpen(true);
  };

  const handleSave = () => {
    const payload = {
      name: formData.name,
      model: formData.model,
      year: Number(formData.year),
      price: Number(formData.price),
      category: formData.category,
      description: formData.description,
      imageUrl: formData.imageUrl,
      range: formData.range,
      topSpeed: formData.topSpeed,
      acceleration: formData.acceleration,
      available: formData.available
    };

    if (editingCar) {
      updateCar.mutate({ carId: editingCar.id, data: payload }, {
        onSuccess: () => {
          toast({ title: "Car Updated", description: "Vehicle details saved successfully." });
          queryClient.invalidateQueries({ queryKey: getListCarsQueryKey() });
          setModalOpen(false);
        },
        onError: (err: any) => toast({ title: "Update Failed", description: err.response?.data?.message, variant: "destructive" })
      });
    } else {
      createCar.mutate({ data: payload }, {
        onSuccess: () => {
          toast({ title: "Car Added", description: "New vehicle added to inventory." });
          queryClient.invalidateQueries({ queryKey: getListCarsQueryKey() });
          setModalOpen(false);
        },
        onError: (err: any) => toast({ title: "Creation Failed", description: err.response?.data?.message, variant: "destructive" })
      });
    }
  };

  const handleDelete = (id: number) => {
    if (!confirm("Are you sure you want to delete this vehicle?")) return;
    deleteCar.mutate({ carId: id }, {
      onSuccess: () => {
        toast({ title: "Car Deleted", description: "Vehicle removed from inventory." });
        queryClient.invalidateQueries({ queryKey: getListCarsQueryKey() });
      }
    });
  };

  if (isLoading) return <LoadingSpinner />;

  return (
    <div className="p-6 md:p-10 space-y-8">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center">
            <CarFront className="mr-3 h-8 w-8 text-primary" />
            Vehicle Inventory
          </h1>
          <p className="text-muted-foreground">Manage marketplace listings.</p>
        </div>
        <Button onClick={openCreate} className="bg-primary hover:bg-primary/90 signal-glow">
          <Plus className="mr-2 h-4 w-4" /> Add Vehicle
        </Button>
      </div>

      <Card className="glass border-white/5">
        <CardContent className="p-0">
          {cars?.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">No vehicles found.</div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/5 hover:bg-transparent">
                    <TableHead>Vehicle</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {cars?.map((car) => (
                    <TableRow key={car.id} className="border-white/5 hover:bg-white/5">
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <img src={car.imageUrl} alt="" className="w-16 h-10 object-cover rounded border border-white/10" />
                          <div>
                            <div className="font-medium">{car.year} {car.name}</div>
                            <div className="text-xs text-muted-foreground">{car.model}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{car.category}</TableCell>
                      <TableCell className="font-bold">${car.price.toLocaleString()}</TableCell>
                      <TableCell>
                        {car.available ? 
                          <span className="text-emerald-500 text-sm font-medium">Available</span> : 
                          <span className="text-destructive text-sm font-medium">Sold Out</span>
                        }
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={() => openEdit(car)}>
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-destructive" onClick={() => handleDelete(car.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="glass border-white/10 max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingCar ? "Edit Vehicle" : "Add New Vehicle"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4 grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Name</Label>
              <Input value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="bg-black/20 border-white/10" />
            </div>
            <div className="space-y-2">
              <Label>Model</Label>
              <Input value={formData.model} onChange={e => setFormData({...formData, model: e.target.value})} className="bg-black/20 border-white/10" />
            </div>
            <div className="space-y-2">
              <Label>Year</Label>
              <Input type="number" value={formData.year} onChange={e => setFormData({...formData, year: Number(e.target.value)})} className="bg-black/20 border-white/10" />
            </div>
            <div className="space-y-2">
              <Label>Price (USD)</Label>
              <Input type="number" value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} className="bg-black/20 border-white/10" />
            </div>
            <div className="space-y-2">
              <Label>Category</Label>
              <Input value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} className="bg-black/20 border-white/10" placeholder="e.g., Performance, SUV" />
            </div>
            <div className="space-y-2">
              <Label>Image URL</Label>
              <Input value={formData.imageUrl} onChange={e => setFormData({...formData, imageUrl: e.target.value})} className="bg-black/20 border-white/10" />
            </div>
            
            {/* Specs */}
            <div className="space-y-2 col-span-2 grid grid-cols-3 gap-4 border-t border-white/10 pt-4 mt-2">
              <div className="space-y-2">
                <Label>Range</Label>
                <Input value={formData.range} onChange={e => setFormData({...formData, range: e.target.value})} className="bg-black/20 border-white/10" placeholder="e.g., 396 mi" />
              </div>
              <div className="space-y-2">
                <Label>0-60 mph</Label>
                <Input value={formData.acceleration} onChange={e => setFormData({...formData, acceleration: e.target.value})} className="bg-black/20 border-white/10" placeholder="e.g., 1.99 s" />
              </div>
              <div className="space-y-2">
                <Label>Top Speed</Label>
                <Input value={formData.topSpeed} onChange={e => setFormData({...formData, topSpeed: e.target.value})} className="bg-black/20 border-white/10" placeholder="e.g., 200 mph" />
              </div>
            </div>

            <div className="space-y-2 col-span-2">
              <Label>Description</Label>
              <Textarea value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="bg-black/20 border-white/10" />
            </div>

            <div className="flex items-center space-x-2 col-span-2">
              <Switch id="available" checked={formData.available} onCheckedChange={c => setFormData({...formData, available: c})} />
              <Label htmlFor="available">Available for purchase</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" className="glass border-white/10" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={createCar.isPending || updateCar.isPending} className="bg-primary hover:bg-primary/90 signal-glow">
              {(createCar.isPending || updateCar.isPending) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {editingCar ? "Save Changes" : "Add Vehicle"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
