import { useListInvestments, useUpdateInvestment, getListInvestmentsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { StatusBadge } from "@/components/StatusBadge";
import { TrendingUp, CheckCircle, XCircle } from "lucide-react";

export default function AdminInvestments() {
  const { data: investments, isLoading } = useListInvestments();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const updateInvestment = useUpdateInvestment();

  const handleUpdateStatus = (id: number, status: string) => {
    updateInvestment.mutate({
      investmentId: id,
      data: { status: status as any }
    }, {
      onSuccess: () => {
        toast({ title: "Investment Updated", description: `Investment status changed to ${status}.` });
        queryClient.invalidateQueries({ queryKey: getListInvestmentsQueryKey() });
      },
      onError: (err: any) => {
        toast({ title: "Update Failed", description: err.response?.data?.message, variant: "destructive" });
      }
    });
  };

  if (isLoading) return <LoadingSpinner />;

  return (
    <div className="p-6 md:p-10 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center">
            <TrendingUp className="mr-3 h-8 w-8 text-primary" />
            Investments
          </h1>
          <p className="text-muted-foreground">Manage user investment portfolios.</p>
        </div>
      </div>

      <Card className="glass border-white/5">
        <CardContent className="p-0">
          {investments?.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">No investments found.</div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/5 hover:bg-transparent">
                    <TableHead>Investor</TableHead>
                    <TableHead>Plan</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Earned</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {investments?.map((inv) => (
                    <TableRow key={inv.id} className="border-white/5 hover:bg-white/5">
                      <TableCell>
                        <div className="font-medium">{inv.user?.firstName} {inv.user?.lastName}</div>
                        <div className="text-xs text-muted-foreground">{inv.user?.email}</div>
                      </TableCell>
                      <TableCell className="capitalize">{inv.plan.replace('fan_', '')}</TableCell>
                      <TableCell className="font-bold">${inv.amount.toLocaleString()}</TableCell>
                      <TableCell className="font-bold text-emerald-500">${inv.totalEarned.toLocaleString()}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{format(new Date(inv.createdAt), 'MMM dd, yyyy')}</TableCell>
                      <TableCell><StatusBadge status={inv.status} /></TableCell>
                      <TableCell className="text-right">
                        {inv.status === 'pending' && (
                          <div className="flex justify-end gap-2">
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="h-8 w-8 p-0 border-emerald-500/20 text-emerald-500 hover:bg-emerald-500/10"
                              onClick={() => handleUpdateStatus(inv.id, 'active')}
                            >
                              <CheckCircle className="h-4 w-4" />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="h-8 w-8 p-0 border-destructive/20 text-destructive hover:bg-destructive/10"
                              onClick={() => handleUpdateStatus(inv.id, 'cancelled')}
                            >
                              <XCircle className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                        {inv.status === 'active' && (
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="h-8 text-xs glass border-white/10"
                            onClick={() => handleUpdateStatus(inv.id, 'completed')}
                          >
                            Mark Completed
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
