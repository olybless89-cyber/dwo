import { useState } from "react";
import { useListOrders, useUpdateOrder, getListOrdersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { StatusBadge } from "@/components/StatusBadge";
import { ShoppingCart } from "lucide-react";

export default function AdminOrders() {
  const { data: orders, isLoading } = useListOrders();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const updateOrder = useUpdateOrder();

  const handleStatusChange = (orderId: number, newStatus: string) => {
    updateOrder.mutate({
      orderId,
      data: { status: newStatus as any }
    }, {
      onSuccess: () => {
        toast({ title: "Order Updated", description: `Order status changed to ${newStatus}.` });
        queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() });
      },
      onError: (err: any) => {
        toast({ title: "Update Failed", description: err.response?.data?.message, variant: "destructive" });
      }
    });
  };

  if (isLoading) return <LoadingSpinner />;

  return (
    <div className="p-6 md:p-10 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center">
            <ShoppingCart className="mr-3 h-8 w-8 text-primary" />
            Vehicle Orders
          </h1>
          <p className="text-muted-foreground">Manage user vehicle purchases and delivery status.</p>
        </div>
      </div>

      <Card className="glass border-white/5">
        <CardContent className="p-0">
          {orders?.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">No orders found.</div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/5 hover:bg-transparent">
                    <TableHead>Order ID</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Vehicle</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders?.map((order) => (
                    <TableRow key={order.id} className="border-white/5 hover:bg-white/5">
                      <TableCell className="font-mono text-xs">#{order.id}</TableCell>
                      <TableCell>
                        <div className="font-medium">{order.user?.firstName} {order.user?.lastName}</div>
                        <div className="text-xs text-muted-foreground">{order.user?.email}</div>
                      </TableCell>
                      <TableCell className="font-medium">
                        {order.car?.year} {order.car?.name}
                      </TableCell>
                      <TableCell className="font-bold">${order.amount.toLocaleString()}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{format(new Date(order.createdAt), 'MMM dd, yyyy')}</TableCell>
                      <TableCell><StatusBadge status={order.status} /></TableCell>
                      <TableCell className="text-right">
                        <Select 
                          defaultValue={order.status} 
                          onValueChange={(val) => handleStatusChange(order.id, val)}
                        >
                          <SelectTrigger className="w-[130px] h-8 bg-black/20 border-white/10 ml-auto text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">Pending</SelectItem>
                            <SelectItem value="processing">Processing</SelectItem>
                            <SelectItem value="confirmed">Confirmed</SelectItem>
                            <SelectItem value="delivered">Delivered</SelectItem>
                            <SelectItem value="cancelled">Cancelled</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
