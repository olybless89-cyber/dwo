import { useListTransactions, useUpdateTransaction, getListTransactionsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { StatusBadge } from "@/components/StatusBadge";
import { ArrowLeftRight, CheckCircle, XCircle } from "lucide-react";

export default function AdminTransactions() {
  const { data: transactions, isLoading } = useListTransactions();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const updateTransaction = useUpdateTransaction();

  const handleUpdateStatus = (id: number, status: string) => {
    updateTransaction.mutate({
      transactionId: id,
      data: { status: status as any }
    }, {
      onSuccess: () => {
        toast({ title: "Transaction Updated", description: `Transaction marked as ${status}.` });
        queryClient.invalidateQueries({ queryKey: getListTransactionsQueryKey() });
      },
      onError: (err: any) => {
        toast({ title: "Update Failed", description: err.response?.data?.message, variant: "destructive" });
      }
    });
  };

  if (isLoading) return <LoadingSpinner />;

  return (
    <div className="p-6 md:p-10 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center">
            <ArrowLeftRight className="mr-3 h-8 w-8 text-primary" />
            Financial Transactions
          </h1>
          <p className="text-muted-foreground">Approve or reject user deposits and withdrawals.</p>
        </div>
      </div>

      <Card className="glass border-white/5">
        <CardContent className="p-0">
          {transactions?.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">No transactions found.</div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/5 hover:bg-transparent">
                    <TableHead>User</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Method/Ref</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions?.map((tx) => (
                    <TableRow key={tx.id} className="border-white/5 hover:bg-white/5">
                      <TableCell>
                        <div className="font-medium">{tx.user?.firstName} {tx.user?.lastName}</div>
                        <div className="text-xs text-muted-foreground">{tx.user?.email}</div>
                      </TableCell>
                      <TableCell className="capitalize font-medium">{tx.type}</TableCell>
                      <TableCell>
                        <div className="uppercase text-xs font-bold">{tx.method}</div>
                        {tx.reference && <div className="font-mono text-xs text-muted-foreground mt-1 max-w-[150px] truncate" title={tx.reference}>{tx.reference}</div>}
                      </TableCell>
                      <TableCell className={`font-bold ${tx.type === 'deposit' ? 'text-emerald-500' : 'text-white'}`}>
                        {tx.type === 'deposit' ? '+' : '-'}${tx.amount.toLocaleString()}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">{format(new Date(tx.createdAt), 'MMM dd, yyyy')}</TableCell>
                      <TableCell><StatusBadge status={tx.status} /></TableCell>
                      <TableCell className="text-right">
                        {tx.status === 'pending' && (
                          <div className="flex justify-end gap-2">
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="h-8 w-8 p-0 border-emerald-500/20 text-emerald-500 hover:bg-emerald-500/10"
                              onClick={() => handleUpdateStatus(tx.id, 'approved')}
                              title="Approve"
                            >
                              <CheckCircle className="h-4 w-4" />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="h-8 w-8 p-0 border-destructive/20 text-destructive hover:bg-destructive/10"
                              onClick={() => handleUpdateStatus(tx.id, 'rejected')}
                              title="Reject"
                            >
                              <XCircle className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
