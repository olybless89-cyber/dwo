import { useState } from "react";
import { useListGiveaways, useCreateGiveaway, getListGiveawaysQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { StatusBadge } from "@/components/StatusBadge";
import { Gift, Loader2, Plus } from "lucide-react";

export default function AdminGiveaways() {
  const { data: giveaways, isLoading } = useListGiveaways();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [createOpen, setCreateOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    value: "",
    description: "",
    imageUrl: "",
    endDate: "",
    maxEntries: ""
  });
  
  const createGiveaway = useCreateGiveaway();

  const handleCreate = () => {
    createGiveaway.mutate({
      data: {
        title: formData.title,
        value: Number(formData.value),
        description: formData.description,
        imageUrl: formData.imageUrl,
        endDate: new Date(formData.endDate).toISOString(),
        maxEntries: Number(formData.maxEntries)
      }
    }, {
      onSuccess: () => {
        toast({ title: "Giveaway Created", description: "The giveaway is now active." });
        queryClient.invalidateQueries({ queryKey: getListGiveawaysQueryKey() });
        setCreateOpen(false);
        setFormData({ title: "", value: "", description: "", imageUrl: "", endDate: "", maxEntries: "" });
      },
      onError: (err: any) => {
        toast({ title: "Creation Failed", description: err.response?.data?.message, variant: "destructive" });
      }
    });
  };

  if (isLoading) return <LoadingSpinner />;

  return (
    <div className="p-6 md:p-10 space-y-8">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center">
            <Gift className="mr-3 h-8 w-8 text-primary" />
            Giveaways
          </h1>
          <p className="text-muted-foreground">Manage promotional giveaways for members.</p>
        </div>
        <Button onClick={() => setCreateOpen(true)} className="bg-primary hover:bg-primary/90 signal-glow">
          <Plus className="mr-2 h-4 w-4" /> New Giveaway
        </Button>
      </div>

      <Card className="glass border-white/5">
        <CardContent className="p-0">
          {giveaways?.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">No giveaways found.</div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/5 hover:bg-transparent">
                    <TableHead>Giveaway</TableHead>
                    <TableHead>Value</TableHead>
                    <TableHead>Entries</TableHead>
                    <TableHead>End Date</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {giveaways?.map((giveaway) => (
                    <TableRow key={giveaway.id} className="border-white/5 hover:bg-white/5">
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <img src={giveaway.imageUrl} alt="" className="w-12 h-12 object-cover rounded border border-white/10" />
                          <div className="font-medium">{giveaway.title}</div>
                        </div>
                      </TableCell>
                      <TableCell className="font-bold">${giveaway.value.toLocaleString()}</TableCell>
                      <TableCell>{giveaway.totalEntries} / {giveaway.maxEntries}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{format(new Date(giveaway.endDate), 'MMM dd, yyyy')}</TableCell>
                      <TableCell><StatusBadge status={giveaway.status} /></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="glass border-white/10 max-w-lg">
          <DialogHeader>
            <DialogTitle>Create New Giveaway</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4 grid grid-cols-2 gap-4">
            <div className="space-y-2 col-span-2">
              <Label>Title</Label>
              <Input 
                value={formData.title} 
                onChange={e => setFormData({...formData, title: e.target.value})}
                className="bg-black/20 border-white/10"
              />
            </div>
            <div className="space-y-2">
              <Label>Value (USD)</Label>
              <Input 
                type="number" 
                value={formData.value} 
                onChange={e => setFormData({...formData, value: e.target.value})}
                className="bg-black/20 border-white/10"
              />
            </div>
            <div className="space-y-2">
              <Label>Max Entries</Label>
              <Input 
                type="number" 
                value={formData.maxEntries} 
                onChange={e => setFormData({...formData, maxEntries: e.target.value})}
                className="bg-black/20 border-white/10"
              />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>Image URL</Label>
              <Input 
                value={formData.imageUrl} 
                onChange={e => setFormData({...formData, imageUrl: e.target.value})}
                className="bg-black/20 border-white/10"
                placeholder="https://..."
              />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>End Date</Label>
              <Input 
                type="datetime-local" 
                value={formData.endDate} 
                onChange={e => setFormData({...formData, endDate: e.target.value})}
                className="bg-black/20 border-white/10 block w-full"
              />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>Description</Label>
              <Textarea 
                value={formData.description} 
                onChange={e => setFormData({...formData, description: e.target.value})}
                className="bg-black/20 border-white/10 min-h-[100px]"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" className="glass border-white/10" onClick={() => setCreateOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate} disabled={createGiveaway.isPending} className="bg-primary hover:bg-primary/90 signal-glow">
              {createGiveaway.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Launch Giveaway
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
