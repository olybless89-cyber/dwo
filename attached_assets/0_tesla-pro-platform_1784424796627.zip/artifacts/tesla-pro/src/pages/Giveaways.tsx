import { useListGiveaways, useEnterGiveaway } from "@workspace/api-client-react";
import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { useToast } from "@/hooks/use-toast";
import { Gift, Users, Clock, Loader2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { getListGiveawaysQueryKey } from "@workspace/api-client-react";
import { formatDistanceToNow } from "date-fns";

export default function Giveaways() {
  const { data: giveaways, isLoading } = useListGiveaways();
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const enterGiveaway = useEnterGiveaway();

  const handleEnterClick = (id: number) => {
    if (!isAuthenticated) {
      setLocation("/login");
      return;
    }
    
    enterGiveaway.mutate({ giveawayId: id }, {
      onSuccess: () => {
        toast({ title: "Entered Successfully", description: "You have been entered into the giveaway!" });
        queryClient.invalidateQueries({ queryKey: getListGiveawaysQueryKey() });
      },
      onError: (err: any) => {
        toast({
          title: "Entry Failed",
          description: err.response?.data?.message || "Failed to enter giveaway.",
          variant: "destructive"
        });
      }
    });
  };

  const activeGiveaways = giveaways?.filter(g => g.status === 'active') || [];
  const pastGiveaways = giveaways?.filter(g => g.status === 'completed') || [];

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-12 text-center">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tighter mb-4">Pro Member Giveaways</h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Exclusive draws for custom vehicles, accessories, and VIP experiences.
        </p>
      </div>

      {isLoading ? (
        <LoadingSpinner />
      ) : (
        <div className="space-y-16">
          <section>
            <h2 className="text-2xl font-bold mb-6 flex items-center"><Gift className="mr-2 text-primary" /> Active Giveaways</h2>
            {activeGiveaways.length === 0 ? (
              <div className="glass p-12 text-center rounded-xl border border-white/5">
                <p className="text-muted-foreground">No active giveaways at the moment. Check back soon!</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {activeGiveaways.map(giveaway => (
                  <Card key={giveaway.id} className="glass border-primary/20 overflow-hidden relative shadow-[0_0_20px_rgba(232,33,39,0.1)]">
                    <div className="absolute top-4 right-4 z-10 flex gap-2">
                      <Badge className="bg-primary/20 text-primary border-primary/50 backdrop-blur-md">
                        Value: ${giveaway.value.toLocaleString()}
                      </Badge>
                    </div>
                    <div className="h-64 relative overflow-hidden bg-black/50">
                      <img 
                        src={giveaway.imageUrl || "https://digitalassets.tesla.com/tesla-contents/image/upload/f_auto,q_auto/Cybertruck-Hero-Desktop.jpg"} 
                        alt={giveaway.title} 
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background to-transparent p-6 pt-20">
                        <CardTitle className="text-3xl font-bold">{giveaway.title}</CardTitle>
                      </div>
                    </div>
                    <CardContent className="pt-6">
                      <p className="text-muted-foreground mb-6 line-clamp-2">{giveaway.description}</p>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-white/5 p-4 rounded-lg border border-white/5">
                          <div className="flex items-center text-muted-foreground mb-1">
                            <Clock className="w-4 h-4 mr-2" /> Ends in
                          </div>
                          <div className="font-bold">{formatDistanceToNow(new Date(giveaway.endDate))}</div>
                        </div>
                        <div className="bg-white/5 p-4 rounded-lg border border-white/5">
                          <div className="flex items-center text-muted-foreground mb-1">
                            <Users className="w-4 h-4 mr-2" /> Entries
                          </div>
                          <div className="font-bold">{giveaway.totalEntries} / {giveaway.maxEntries}</div>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button 
                        className="w-full bg-primary hover:bg-primary/90 signal-glow" 
                        size="lg"
                        onClick={() => handleEnterClick(giveaway.id)}
                        disabled={enterGiveaway.isPending}
                      >
                        {enterGiveaway.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                        Enter Giveaway
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}
          </section>

          {pastGiveaways.length > 0 && (
            <section>
              <h2 className="text-2xl font-bold mb-6 text-muted-foreground">Past Winners</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {pastGiveaways.map(giveaway => (
                  <Card key={giveaway.id} className="glass border-white/5 opacity-70 hover:opacity-100 transition-opacity">
                    <div className="h-40 overflow-hidden bg-black/40">
                      <img 
                        src={giveaway.imageUrl} 
                        alt={giveaway.title} 
                        className="w-full h-full object-cover grayscale"
                      />
                    </div>
                    <CardHeader>
                      <CardTitle className="text-lg">{giveaway.title}</CardTitle>
                      <div className="text-sm text-muted-foreground">Value: ${giveaway.value.toLocaleString()}</div>
                    </CardHeader>
                    <CardContent>
                      <Badge variant="secondary" className="bg-white/10">Completed</Badge>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
}
