import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { useLogout } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { 
  LayoutDashboard, 
  Wallet, 
  TrendingUp, 
  ShoppingCart, 
  LogOut,
  Users,
  CarFront,
  Gift,
  ArrowLeftRight,
  ShieldCheck,
  Menu
} from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

export function DashboardLayout({ children, admin = false }: { children: ReactNode; admin?: boolean }) {
  const { user } = useAuth();
  const logout = useLogout();
  const queryClient = useQueryClient();
  const [location] = useLocation();

  const handleLogout = () => {
    logout.mutate(undefined, {
      onSuccess: () => {
        queryClient.clear();
        window.location.href = "/";
      },
    });
  };

  const userLinks = [
    { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
    { href: "/dashboard/wallet", label: "Wallet", icon: Wallet },
    { href: "/dashboard/investments", label: "Investments", icon: TrendingUp },
    { href: "/dashboard/orders", label: "Orders", icon: ShoppingCart },
  ];

  const adminLinks = [
    { href: "/admin", label: "Command Center", icon: ShieldCheck },
    { href: "/admin/users", label: "Users", icon: Users },
    { href: "/admin/cars", label: "Inventory", icon: CarFront },
    { href: "/admin/investments", label: "Investments", icon: TrendingUp },
    { href: "/admin/orders", label: "Orders", icon: ShoppingCart },
    { href: "/admin/transactions", label: "Transactions", icon: ArrowLeftRight },
    { href: "/admin/giveaways", label: "Giveaways", icon: Gift },
  ];

  const links = admin ? adminLinks : userLinks;

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-card glass border-r border-white/5">
      <div className="p-6">
        <Link href="/" className="flex items-center space-x-2">
          <span className="font-bold text-xl tracking-tighter">TESLA<span className="text-primary font-light">PRO</span></span>
        </Link>
        {admin && <div className="mt-1 text-xs text-primary font-semibold tracking-wider uppercase">Admin Portal</div>}
      </div>
      <div className="px-4 pb-4">
        <div className="text-sm font-medium mb-1 px-2">{user?.firstName} {user?.lastName}</div>
        <div className="text-xs text-muted-foreground px-2">{user?.email}</div>
      </div>
      <nav className="flex-1 px-4 space-y-1 overflow-y-auto">
        {links.map((link) => {
          const Icon = link.icon;
          const isActive = location === link.href;
          return (
            <Link key={link.href} href={link.href}>
              <div className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors cursor-pointer",
                isActive 
                  ? "bg-primary text-primary-foreground signal-glow" 
                  : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
              )}>
                <Icon className="h-4 w-4" />
                {link.label}
              </div>
            </Link>
          );
        })}
      </nav>
      <div className="p-4 border-t border-white/5">
        <Link href={admin ? "/dashboard" : "/admin"} className="block mb-2">
          {admin ? (
            <Button variant="outline" className="w-full justify-start glass border-white/10" size="sm">
              <ArrowLeftRight className="mr-2 h-4 w-4" /> Exit Admin
            </Button>
          ) : user?.role === 'admin' && (
            <Button variant="outline" className="w-full justify-start glass border-white/10" size="sm">
              <ShieldCheck className="mr-2 h-4 w-4" /> Admin Portal
            </Button>
          )}
        </Link>
        <Button variant="ghost" className="w-full justify-start text-muted-foreground hover:text-foreground" onClick={handleLogout}>
          <LogOut className="mr-2 h-4 w-4" /> Sign Out
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-[100dvh] flex bg-background selection:bg-primary/30">
      {/* Desktop Sidebar */}
      <aside className="hidden md:block w-64 shrink-0">
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar & Header */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="md:hidden sticky top-0 z-50 flex h-14 items-center gap-4 border-b border-white/5 bg-background/80 px-4 backdrop-blur-md glass">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="shrink-0">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 p-0 border-r-white/5 glass">
              <SidebarContent />
            </SheetContent>
          </Sheet>
          <Link href="/" className="font-bold text-lg tracking-tighter">
            TESLA<span className="text-primary font-light">PRO</span>
          </Link>
        </header>
        
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
