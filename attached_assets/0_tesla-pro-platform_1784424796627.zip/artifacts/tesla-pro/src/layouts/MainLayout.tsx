import { ReactNode } from "react";
import { Link } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { useLogout } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Menu } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export function MainLayout({ children }: { children: ReactNode }) {
  const { user, isAuthenticated, isAdmin } = useAuth();
  const logout = useLogout();
  const queryClient = useQueryClient();

  const handleLogout = () => {
    logout.mutate(undefined, {
      onSuccess: () => {
        queryClient.clear();
        window.location.href = "/";
      },
    });
  };

  const NavLinks = () => (
    <>
      <Link href="/shop" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Shop</Link>
      <Link href="/giveaways" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Giveaways</Link>
      <Link href="/membership" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Membership</Link>
    </>
  );

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background selection:bg-primary/30">
      <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-background/80 backdrop-blur-md">
        <div className="container flex h-16 items-center justify-between mx-auto px-4">
          <div className="flex items-center gap-6 md:gap-10">
            <Link href="/" className="flex items-center space-x-2">
              <span className="font-bold text-xl tracking-tighter">TESLA<span className="text-primary font-light">PRO</span></span>
            </Link>
            <nav className="hidden md:flex gap-6">
              <NavLinks />
            </nav>
          </div>

          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <div className="hidden md:flex items-center gap-4">
                {isAdmin && (
                  <Link href="/admin" className="text-sm font-medium text-primary hover:text-primary/80 transition-colors">
                    Admin
                  </Link>
                )}
                <Link href="/dashboard" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                  Dashboard
                </Link>
                <Button variant="outline" size="sm" onClick={handleLogout} className="border-white/10 glass">
                  Sign out
                </Button>
              </div>
            ) : (
              <div className="hidden md:flex items-center gap-4">
                <Link href="/login" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                  Sign in
                </Link>
                <Link href="/register">
                  <Button size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground signal-glow">
                    Join Pro
                  </Button>
                </Link>
              </div>
            )}

            <Sheet>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Toggle Menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="glass border-l-white/10">
                <nav className="flex flex-col gap-4 mt-8">
                  <NavLinks />
                  <div className="h-px bg-white/10 my-4" />
                  {isAuthenticated ? (
                    <>
                      {isAdmin && (
                        <Link href="/admin" className="text-sm font-medium text-primary">Admin</Link>
                      )}
                      <Link href="/dashboard" className="text-sm font-medium">Dashboard</Link>
                      <Button variant="ghost" className="justify-start px-0 text-muted-foreground" onClick={handleLogout}>
                        Sign out
                      </Button>
                    </>
                  ) : (
                    <>
                      <Link href="/login" className="text-sm font-medium">Sign in</Link>
                      <Link href="/register" className="text-sm font-medium text-primary">Join Pro</Link>
                    </>
                  )}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>
      <main className="flex-1 flex flex-col">{children}</main>
      <footer className="border-t border-white/10 py-6 md:py-0 glass">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row mx-auto px-4">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} Tesla Pro Platform. All rights reserved. Not affiliated with Tesla, Inc.
          </p>
        </div>
      </footer>
    </div>
  );
}
