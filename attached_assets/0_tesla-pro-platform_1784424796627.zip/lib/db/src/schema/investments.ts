import { pgTable, serial, integer, decimal, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const investmentPlanEnum = pgEnum("investment_plan", ["fan_explorer", "fan_insider", "fan_founder"]);
export const investmentStatusEnum = pgEnum("investment_status", ["pending", "active", "completed", "cancelled"]);

export const investmentsTable = pgTable("investments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => usersTable.id).notNull(),
  plan: investmentPlanEnum("plan").notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  dailyReturn: decimal("daily_return", { precision: 5, scale: 2 }).default("0").notNull(),
  totalEarned: decimal("total_earned", { precision: 12, scale: 2 }).default("0").notNull(),
  status: investmentStatusEnum("status").default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertInvestmentSchema = createInsertSchema(investmentsTable).omit({ id: true, createdAt: true });
export type InsertInvestment = z.infer<typeof insertInvestmentSchema>;
export type Investment = typeof investmentsTable.$inferSelect;
