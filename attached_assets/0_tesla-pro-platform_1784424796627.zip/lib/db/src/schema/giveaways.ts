import { pgTable, serial, integer, decimal, varchar, text, timestamp, pgEnum, unique } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const giveawayStatusEnum = pgEnum("giveaway_status", ["active", "completed", "cancelled"]);

export const giveawaysTable = pgTable("giveaways", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  value: decimal("value", { precision: 12, scale: 2 }).notNull(),
  description: text("description"),
  imageUrl: text("image_url").notNull(),
  endDate: timestamp("end_date").notNull(),
  totalEntries: integer("total_entries").default(0).notNull(),
  maxEntries: integer("max_entries").notNull(),
  status: giveawayStatusEnum("status").default("active").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const giveawayEntriesTable = pgTable("giveaway_entries", {
  id: serial("id").primaryKey(),
  giveawayId: integer("giveaway_id").references(() => giveawaysTable.id).notNull(),
  userId: integer("user_id").references(() => usersTable.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t) => [unique().on(t.giveawayId, t.userId)]);

export const insertGiveawaySchema = createInsertSchema(giveawaysTable).omit({ id: true, createdAt: true });
export type InsertGiveaway = z.infer<typeof insertGiveawaySchema>;
export type Giveaway = typeof giveawaysTable.$inferSelect;
export type GiveawayEntry = typeof giveawayEntriesTable.$inferSelect;
