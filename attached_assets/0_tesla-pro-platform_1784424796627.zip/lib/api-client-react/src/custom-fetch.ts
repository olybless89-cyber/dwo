/**
 * Custom fetch wrapper for Tesla Pro API.
 *
 * The orval-generated client calls:
 *   customFetch<T>(url: string, init: RequestInit): Promise<T>
 * and expects the PARSED JSON data back (not the raw Response).
 *
 * We also attach session cookies (credentials: 'include') on every request so
 * the server-side express-session auth works correctly.
 */

let baseUrl = "";
let authTokenGetter: AuthTokenGetter | null = null;

export type AuthTokenGetter = () => string | null | Promise<string | null>;

export function setBaseUrl(url: string) {
  baseUrl = url;
}

export function setAuthTokenGetter(getter: AuthTokenGetter) {
  authTokenGetter = getter;
}

// These type aliases are required by the orval code-generator.
export type ErrorType<T> = T & { status?: number };
export type BodyType<T> = T;

export const customFetch = async <T>(
  input: RequestInfo | URL,
  init?: RequestInit,
): Promise<T> => {
  // Build the final URL (prepend baseUrl only for string paths that lack a host)
  let url: RequestInfo | URL = input;
  if (typeof input === "string" && baseUrl && !input.startsWith("http")) {
    url = `${baseUrl}${input}`;
  }

  // Attach an auth token header if a getter is configured
  const extraHeaders: Record<string, string> = {};
  if (authTokenGetter) {
    const token = await authTokenGetter();
    if (token) extraHeaders["Authorization"] = `Bearer ${token}`;
  }

  const response = await fetch(url, {
    ...init,
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...extraHeaders,
      ...(init?.headers as Record<string, string> | undefined),
    },
  });

  // Throw a structured error for non-2xx responses
  if (!response.ok) {
    let errorBody: unknown;
    try {
      errorBody = await response.json();
    } catch {
      errorBody = { error: response.statusText };
    }
    const err = new Error(
      (errorBody as Record<string, string>)?.error ?? response.statusText,
    ) as Error & { status: number; data: unknown };
    err.status = response.status;
    err.data = errorBody;
    throw err;
  }

  // 204 No Content — return undefined rather than crashing on empty body
  if (response.status === 204 || response.headers.get("content-length") === "0") {
    return undefined as T;
  }

  return response.json() as Promise<T>;
};
